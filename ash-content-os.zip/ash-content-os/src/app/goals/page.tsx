"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import type { WeeklyGoal, QuarterlyGoal } from "@/types";
import { Plus, X } from "lucide-react";

function Progress({ label, actual, target, color, size = "md" }: { label: string; actual: number; target: number; color?: string; size?: "sm" | "md" }) {
  const pct = target > 0 ? Math.min(100, Math.round((actual / target) * 100)) : 0;
  return (
    <div style={{ marginBottom: size === "sm" ? 10 : 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
        <span style={{ fontSize: size === "sm" ? 12 : 13, color: "#444140" }}>{label}</span>
        <span style={{ fontSize: size === "sm" ? 11 : 12, color: pct >= 100 ? "#065F46" : "#9A9188" }}>{actual} / {target} <span style={{ color: pct >= 100 ? "#065F46" : "#B89A5A" }}>({pct}%)</span></span>
      </div>
      <div className="progress-bar" style={{ height: size === "sm" ? 4 : 6 }}>
        <div className="progress-fill" style={{ width: `${pct}%`, background: pct >= 100 ? "#4ade80" : (color || "#B89A5A") }} />
      </div>
    </div>
  );
}

function WeeklyModal({ goal, onClose, onSave }: { goal: Partial<WeeklyGoal> | null; onClose: () => void; onSave: () => void }) {
  const today = new Date();
  const monday = new Date(today);
  monday.setDate(today.getDate() - today.getDay() + 1);
  const defaultWeek = monday.toISOString().split("T")[0];

  const [form, setForm] = useState<Partial<WeeklyGoal>>(goal || {
    week_of: defaultWeek,
    ac_posts_target: 5, ac_posts_actual: 0,
    dca_posts_target: 3, dca_posts_actual: 0,
    lll_posts_target: 2, lll_posts_actual: 0,
    oog_posts_target: 2, oog_posts_actual: 0,
    des_posts_target: 2, des_posts_actual: 0,
    tiktok_posts_target: 7, tiktok_posts_actual: 0,
    tiktok_lives_target: 3, tiktok_lives_actual: 0,
    webinars_target: 1, webinars_actual: 0,
    strategy_calls_target: 8, strategy_calls_actual: 0,
    revenue_target: 0, revenue_actual: 0,
    posting_streak: 0,
  });
  const [saving, setSaving] = useState(false);
  const n = (k: keyof WeeklyGoal) => (e: React.ChangeEvent<HTMLInputElement>) => setForm(f => ({ ...f, [k]: e.target.type === "number" ? Number(e.target.value) : e.target.value }));

  async function save() {
    setSaving(true);
    if (form.id) await supabase.from("weekly_goals").update(form).eq("id", form.id);
    else await supabase.from("weekly_goals").insert(form);
    setSaving(false);
    onSave(); onClose();
  }

  const Row = ({ label, tk, ak }: { label: string; tk: keyof WeeklyGoal; ak: keyof WeeklyGoal }) => (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 80px 80px", gap: 8, alignItems: "center", marginBottom: 8 }}>
      <span style={{ fontSize: 13, color: "#444140" }}>{label}</span>
      <input className="input" type="number" value={form[tk] as number || 0} onChange={n(tk)} style={{ textAlign: "center" }} />
      <input className="input" type="number" value={form[ak] as number || 0} onChange={n(ak)} style={{ textAlign: "center" }} />
    </div>
  );

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{ maxWidth: 540 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div className="font-display" style={{ fontSize: 22 }}>{form.id ? "Edit Week" : "New Weekly Plan"}</div>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "#9A9188" }}><X size={18} /></button>
        </div>
        <div style={{ marginBottom: 16 }}>
          <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Week of</label>
          <input className="input" type="date" value={form.week_of || defaultWeek} onChange={e => setForm(f => ({ ...f, week_of: e.target.value }))} style={{ width: 160 }} />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 80px 80px", gap: 8, marginBottom: 8 }}>
          <div style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188" }}>Metric</div>
          <div style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", textAlign: "center" }}>Target</div>
          <div style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", textAlign: "center" }}>Actual</div>
        </div>
        <Row label="AC Posts" tk="ac_posts_target" ak="ac_posts_actual" />
        <Row label="DCA Posts" tk="dca_posts_target" ak="dca_posts_actual" />
        <Row label="LLL Posts" tk="lll_posts_target" ak="lll_posts_actual" />
        <Row label="OOG Posts" tk="oog_posts_target" ak="oog_posts_actual" />
        <Row label="TikTok Posts" tk="tiktok_posts_target" ak="tiktok_posts_actual" />
        <Row label="TikTok Lives" tk="tiktok_lives_target" ak="tiktok_lives_actual" />
        <Row label="Webinars" tk="webinars_target" ak="webinars_actual" />
        <Row label="Strategy Calls" tk="strategy_calls_target" ak="strategy_calls_actual" />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 80px 80px", gap: 8, alignItems: "center", marginBottom: 8 }}>
          <span style={{ fontSize: 13, color: "#444140" }}>Revenue $</span>
          <input className="input" type="number" value={form.revenue_target || 0} onChange={n("revenue_target")} style={{ textAlign: "center" }} />
          <input className="input" type="number" value={form.revenue_actual || 0} onChange={n("revenue_actual")} style={{ textAlign: "center" }} />
        </div>
        <div style={{ marginTop: 8 }}>
          <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Top 3 Priorities</label>
          <textarea className="input" rows={3} value={form.top_3_priorities || ""} onChange={e => setForm(f => ({ ...f, top_3_priorities: e.target.value }))} placeholder="1. &#10;2. &#10;3." style={{ resize: "vertical" }} />
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 20, justifyContent: "flex-end" }}>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={saving}>{saving ? "Saving..." : "Save Week"}</button>
        </div>
      </div>
    </div>
  );
}

function QModal({ goal, onClose, onSave }: { goal: Partial<QuarterlyGoal> | null; onClose: () => void; onSave: () => void }) {
  const [form, setForm] = useState<Partial<QuarterlyGoal>>(goal || {
    quarter: "2", year: 2026,
    revenue_target: 135000, revenue_actual: 0,
    ig_followers_target: 10000, ig_followers_actual: 8000,
    dca_clients_target: 10, dca_clients_actual: 0,
    tiktok_followers_target: 5000, tiktok_followers_actual: 0,
  });
  const [saving, setSaving] = useState(false);
  const n = (k: keyof QuarterlyGoal) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setForm(f => ({ ...f, [k]: e.target.type === "number" ? Number(e.target.value) : e.target.value }));

  async function save() {
    setSaving(true);
    if (form.id) await supabase.from("quarterly_goals").update(form).eq("id", form.id);
    else await supabase.from("quarterly_goals").insert(form);
    setSaving(false);
    onSave(); onClose();
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div className="font-display" style={{ fontSize: 22 }}>Quarterly Goals</div>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "#9A9188" }}><X size={18} /></button>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 }}>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Quarter</label>
            <select className="input" value={form.quarter || "2"} onChange={n("quarter")}>
              <option value="1">Q1</option><option value="2">Q2</option><option value="3">Q3</option><option value="4">Q4</option>
            </select>
          </div>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Year</label>
            <input className="input" type="number" value={form.year || 2026} onChange={n("year")} />
          </div>
        </div>
        {[
          { label: "Revenue Target ($)", tk: "revenue_target" as keyof QuarterlyGoal, ak: "revenue_actual" as keyof QuarterlyGoal },
          { label: "IG Followers Target", tk: "ig_followers_target" as keyof QuarterlyGoal, ak: "ig_followers_actual" as keyof QuarterlyGoal },
          { label: "DCA Clients Target", tk: "dca_clients_target" as keyof QuarterlyGoal, ak: "dca_clients_actual" as keyof QuarterlyGoal },
          { label: "TikTok Followers Target", tk: "tiktok_followers_target" as keyof QuarterlyGoal, ak: "tiktok_followers_actual" as keyof QuarterlyGoal },
        ].map(({ label, tk, ak }) => (
          <div key={tk} style={{ display: "grid", gridTemplateColumns: "1fr 100px 100px", gap: 8, alignItems: "center", marginBottom: 10 }}>
            <span style={{ fontSize: 13 }}>{label}</span>
            <input className="input" type="number" value={form[tk] as number || 0} onChange={e => setForm(f => ({ ...f, [tk]: Number(e.target.value) }))} style={{ textAlign: "center" }} />
            <input className="input" type="number" value={form[ak] as number || 0} onChange={e => setForm(f => ({ ...f, [ak]: Number(e.target.value) }))} style={{ textAlign: "center" }} />
          </div>
        ))}
        <div style={{ display: "flex", gap: 10, marginTop: 20, justifyContent: "flex-end" }}>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={saving}>{saving ? "Saving..." : "Save Goals"}</button>
        </div>
      </div>
    </div>
  );
}

export default function GoalsPage() {
  const [weeklies, setWeeklies] = useState<WeeklyGoal[]>([]);
  const [quarterly, setQuarterly] = useState<QuarterlyGoal | null>(null);
  const [loading, setLoading] = useState(true);
  const [weeklyModal, setWeeklyModal] = useState<Partial<WeeklyGoal> | null | false>(false);
  const [qModal, setQModal] = useState<Partial<QuarterlyGoal> | null | false>(false);

  async function load() {
    setLoading(true);
    const [{ data: wg }, { data: qg }] = await Promise.all([
      supabase.from("weekly_goals").select("*").order("week_of", { ascending: false }).limit(8),
      supabase.from("quarterly_goals").select("*").order("year", { ascending: false }).order("quarter", { ascending: false }).limit(1).maybeSingle(),
    ]);
    setWeeklies(wg || []);
    setQuarterly(qg || null);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  const current = weeklies[0];

  return (
    <div style={{ maxWidth: 1100, animation: "slideUp 0.4s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 28 }}>
        <h1 className="font-display" style={{ fontSize: 34, fontWeight: 400 }}>Goals & Tracking</h1>
        <div style={{ display: "flex", gap: 10 }}>
          <button className="btn btn-ghost" onClick={() => setQModal(quarterly || {})}>
            {quarterly ? "Edit Q Goals" : "Set Q Goals"}
          </button>
          <button className="btn btn-primary" onClick={() => setWeeklyModal({})}>
            <Plus size={14} /> New Week
          </button>
        </div>
      </div>

      {loading ? (
        <div style={{ display: "grid", gap: 16 }}>
          {[1,2].map(i => <div key={i} className="skeleton" style={{ height: 200 }} />)}
        </div>
      ) : (
        <div>
          {/* Q Goals */}
          {quarterly && (
            <div className="card" style={{ marginBottom: 24, borderTop: "3px solid #B89A5A" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
                <div>
                  <div className="font-display" style={{ fontSize: 22 }}>Q{quarterly.quarter} {quarterly.year} Goals</div>
                </div>
                <button className="btn btn-ghost" onClick={() => setQModal(quarterly)} style={{ fontSize: 12 }}>Edit</button>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 16 }}>
                <Progress label="Revenue" actual={quarterly.revenue_actual} target={quarterly.revenue_target} color="#B89A5A" />
                <Progress label="IG Followers" actual={quarterly.ig_followers_actual} target={quarterly.ig_followers_target} color="#2C2C2A" />
                <Progress label="DCA Clients" actual={quarterly.dca_clients_actual} target={quarterly.dca_clients_target} color="#C8432A" />
                <Progress label="TikTok Followers" actual={quarterly.tiktok_followers_actual} target={quarterly.tiktok_followers_target} color="#534AB7" />
              </div>
            </div>
          )}

          {/* Current Week */}
          {current && (
            <div className="card" style={{ marginBottom: 20 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
                <div>
                  <div className="font-display" style={{ fontSize: 20 }}>Current Week</div>
                  <div style={{ fontSize: 12, color: "#9A9188" }}>
                    Week of {new Date(current.week_of).toLocaleDateString("en-US", { month: "long", day: "numeric" })}
                  </div>
                </div>
                <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  {current.posting_streak > 0 && (
                    <span style={{ fontSize: 13, color: "#B89A5A" }}>🔥 {current.posting_streak} day streak</span>
                  )}
                  <button className="btn btn-ghost" onClick={() => setWeeklyModal(current)} style={{ fontSize: 12 }}>Update</button>
                </div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 16 }}>
                <Progress label="AC Posts" actual={current.ac_posts_actual} target={current.ac_posts_target} color="#2C2C2A" />
                <Progress label="DCA Posts" actual={current.dca_posts_actual} target={current.dca_posts_target} color="#C8432A" />
                <Progress label="TikTok Posts" actual={current.tiktok_posts_actual} target={current.tiktok_posts_target} color="#534AB7" />
                <Progress label="TikTok Lives" actual={current.tiktok_lives_actual} target={current.tiktok_lives_target} color="#534AB7" />
                <Progress label="Webinars" actual={current.webinars_actual} target={current.webinars_target} color="#185FA5" />
                <Progress label="Strategy Calls" actual={current.strategy_calls_actual} target={current.strategy_calls_target} color="#B89A5A" />
              </div>
              <div style={{ marginTop: 8, paddingTop: 16, borderTop: "1px solid #F7F4F0" }}>
                <Progress label={`Revenue: $${(current.revenue_actual || 0).toLocaleString()} / $${(current.revenue_target || 0).toLocaleString()}`} actual={current.revenue_actual} target={current.revenue_target} color="#B89A5A" />
              </div>
              {current.top_3_priorities && (
                <div style={{ marginTop: 12, padding: "12px 16px", background: "#F7F4F0", borderRadius: 8 }}>
                  <div style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", marginBottom: 6 }}>Top 3 Priorities</div>
                  <div style={{ fontSize: 13, color: "#444140", whiteSpace: "pre-line" }}>{current.top_3_priorities}</div>
                </div>
              )}
            </div>
          )}

          {/* Past weeks table */}
          {weeklies.length > 1 && (
            <div className="card" style={{ padding: 0, overflow: "hidden" }}>
              <div style={{ padding: "16px 20px", borderBottom: "1px solid #F7F4F0" }}>
                <div className="font-display" style={{ fontSize: 18 }}>History</div>
              </div>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Week</th>
                    <th>AC Posts</th>
                    <th>DCA Posts</th>
                    <th>Calls</th>
                    <th>Webinars</th>
                    <th>Revenue</th>
                    <th>Score</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {weeklies.slice(1).map(w => (
                    <tr key={w.id}>
                      <td style={{ fontSize: 12 }}>{new Date(w.week_of).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</td>
                      <td style={{ fontSize: 12 }}>{w.ac_posts_actual}/{w.ac_posts_target}</td>
                      <td style={{ fontSize: 12 }}>{w.dca_posts_actual}/{w.dca_posts_target}</td>
                      <td style={{ fontSize: 12 }}>{w.strategy_calls_actual}/{w.strategy_calls_target}</td>
                      <td style={{ fontSize: 12 }}>{w.webinars_actual}/{w.webinars_target}</td>
                      <td style={{ fontSize: 12 }}>${(w.revenue_actual || 0).toLocaleString()}</td>
                      <td>{w.week_score ? <span style={{ fontSize: 12, fontWeight: 500, color: "#B89A5A" }}>{w.week_score}/10</span> : "—"}</td>
                      <td><button onClick={() => setWeeklyModal(w)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 12, color: "#B89A5A", fontFamily: "var(--font-jost)" }}>Edit</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {weeklies.length === 0 && !quarterly && (
            <div style={{ textAlign: "center", padding: "64px 0" }}>
              <div style={{ fontSize: 13, color: "#9A9188", marginBottom: 16 }}>No goals set yet. Start tracking.</div>
              <button className="btn btn-primary" onClick={() => setWeeklyModal({})}>Set This Week's Goals</button>
            </div>
          )}
        </div>
      )}

      {weeklyModal !== false && <WeeklyModal goal={weeklyModal} onClose={() => setWeeklyModal(false)} onSave={load} />}
      {qModal !== false && <QModal goal={qModal} onClose={() => setQModal(false)} onSave={load} />}
    </div>
  );
}
