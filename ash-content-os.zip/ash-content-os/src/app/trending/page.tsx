"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { Plus, X, TrendingUp, TrendingDown, Minus } from "lucide-react";

interface Trending {
  id: string;
  sound_name: string;
  platform: string | null;
  reel_count: string | null;
  trending_direction: string | null;
  best_content_type: string | null;
  brand_match: string | null;
  use_by_date: string | null;
  status: string | null;
  week_of: string | null;
  created_at: string;
}

const STATUSES = ["Pending review", "Using it", "Passed", "Expired"];
const PLATFORMS = ["Instagram", "TikTok", "YouTube Shorts"];

function TModal({ item, onClose, onSave }: { item: Partial<Trending> | null; onClose: () => void; onSave: () => void }) {
  const today = new Date().toISOString().split("T")[0];
  const [form, setForm] = useState<Partial<Trending>>(item || { status: "Pending review", week_of: today });
  const [saving, setSaving] = useState(false);
  const set = (k: keyof Trending, v: unknown) => setForm(f => ({ ...f, [k]: v }));

  async function save() {
    setSaving(true);
    if (form.id) await supabase.from("trending").update(form).eq("id", form.id);
    else await supabase.from("trending").insert(form);
    setSaving(false);
    onSave(); onClose();
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div className="font-display" style={{ fontSize: 22 }}>{form.id ? "Edit Sound" : "Log Trending Sound"}</div>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "#9A9188" }}><X size={18} /></button>
        </div>
        <div style={{ display: "grid", gap: 12 }}>
          <input className="input" placeholder="Sound / audio name *" value={form.sound_name || ""} onChange={e => set("sound_name", e.target.value)} />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Platform</label>
              <select className="input" value={form.platform || ""} onChange={e => set("platform", e.target.value)}>
                <option value="">—</option>
                {PLATFORMS.map(p => <option key={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Reel Count</label>
              <input className="input" value={form.reel_count || ""} onChange={e => set("reel_count", e.target.value)} placeholder="e.g. 2.4M" />
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Trending Direction</label>
              <select className="input" value={form.trending_direction || ""} onChange={e => set("trending_direction", e.target.value)}>
                <option value="">—</option>
                <option>Rising 🔥</option>
                <option>Peak ⭐</option>
                <option>Declining 📉</option>
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Status</label>
              <select className="input" value={form.status || "Pending review"} onChange={e => set("status", e.target.value)}>
                {STATUSES.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Best Content Type</label>
            <input className="input" value={form.best_content_type || ""} onChange={e => set("best_content_type", e.target.value)} placeholder="e.g. Get ready with me, Day in the life" />
          </div>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Brand Match</label>
            <input className="input" value={form.brand_match || ""} onChange={e => set("brand_match", e.target.value)} placeholder="Which brands can use this?" />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Week Of</label>
              <input className="input" type="date" value={form.week_of || today} onChange={e => set("week_of", e.target.value)} />
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Use By Date</label>
              <input className="input" type="date" value={form.use_by_date || ""} onChange={e => set("use_by_date", e.target.value)} />
            </div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 20, justifyContent: "flex-end" }}>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={saving || !form.sound_name}>{saving ? "Saving..." : "Save"}</button>
        </div>
      </div>
    </div>
  );
}

export default function TrendingPage() {
  const [items, setItems] = useState<Trending[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<Partial<Trending> | null | false>(false);
  const [filterStatus, setFilterStatus] = useState("");

  async function load() {
    setLoading(true);
    const { data } = await supabase.from("trending").select("*").order("created_at", { ascending: false });
    setItems(data || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  const filtered = items.filter(i => !filterStatus || i.status === filterStatus);

  const STATUS_STYLE: Record<string, { bg: string; color: string }> = {
    "Pending review": { bg: "#FEF3C7", color: "#92400E" },
    "Using it": { bg: "#D1FAE5", color: "#065F46" },
    Passed: { bg: "#EDE8E1", color: "#9A9188" },
    Expired: { bg: "#FEE2E2", color: "#991B1B" },
  };

  const DIR_ICON = (d: string | null) => {
    if (!d) return null;
    if (d.includes("Rising")) return <TrendingUp size={13} color="#C8432A" />;
    if (d.includes("Declining")) return <TrendingDown size={13} color="#9A9188" />;
    return <Minus size={13} color="#B89A5A" />;
  };

  return (
    <div style={{ maxWidth: 900, animation: "slideUp 0.4s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
        <div>
          <h1 className="font-display" style={{ fontSize: 34, fontWeight: 400 }}>Trending Sounds</h1>
          <div style={{ fontSize: 13, color: "#9A9188", marginTop: 2 }}>{items.filter(i => i.status === "Using it").length} active · {items.length} logged</div>
        </div>
        <button className="btn btn-primary" onClick={() => setModal({})}><Plus size={14} /> Log Sound</button>
      </div>

      <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
        <select className="input" style={{ width: 160 }} value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
          <option value="">All Statuses</option>
          {STATUSES.map(s => <option key={s}>{s}</option>)}
        </select>
      </div>

      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        {loading ? (
          <div style={{ padding: 24 }}>{[1,2,3,4].map(i => <div key={i} className="skeleton" style={{ height: 44, marginBottom: 8 }} />)}</div>
        ) : filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: "48px 0" }}>
            <TrendingUp size={32} color="#B8B0A5" style={{ margin: "0 auto 12px" }} />
            <div style={{ fontSize: 13, color: "#9A9188", marginBottom: 12 }}>No trending sounds logged yet.</div>
            <button className="btn btn-primary" onClick={() => setModal({})}>Log First Sound</button>
          </div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Sound</th>
                <th>Platform</th>
                <th>Count</th>
                <th>Direction</th>
                <th>Best For</th>
                <th>Brand Match</th>
                <th>Use By</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(item => (
                <tr key={item.id}>
                  <td style={{ fontWeight: 500, fontSize: 13 }}>{item.sound_name}</td>
                  <td style={{ fontSize: 12, color: "#7D7470" }}>{item.platform || "—"}</td>
                  <td style={{ fontSize: 12 }}>{item.reel_count || "—"}</td>
                  <td>
                    <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                      {DIR_ICON(item.trending_direction)}
                      <span style={{ fontSize: 12, color: "#7D7470" }}>{item.trending_direction?.replace(/[🔥⭐📉]/g, "").trim() || "—"}</span>
                    </div>
                  </td>
                  <td style={{ fontSize: 12, color: "#7D7470", maxWidth: 140, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{item.best_content_type || "—"}</td>
                  <td style={{ fontSize: 12, color: "#7D7470" }}>{item.brand_match || "—"}</td>
                  <td style={{ fontSize: 12, color: "#9A9188" }}>
                    {item.use_by_date ? new Date(item.use_by_date).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "—"}
                  </td>
                  <td>
                    <span style={{ fontSize: 11, padding: "3px 8px", borderRadius: 100, ...(STATUS_STYLE[item.status || "Pending review"] || { bg: "#EDE8E1", color: "#9A9188" }), background: (STATUS_STYLE[item.status || "Pending review"] || {}).bg }}>
                      {item.status}
                    </span>
                  </td>
                  <td>
                    <button onClick={() => setModal(item)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 12, color: "#B89A5A", fontFamily: "var(--font-jost)" }}>Edit</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {modal !== false && <TModal item={modal} onClose={() => setModal(false)} onSave={load} />}
    </div>
  );
}
