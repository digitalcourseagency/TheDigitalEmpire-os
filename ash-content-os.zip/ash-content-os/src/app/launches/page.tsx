"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import type { Launch } from "@/types";
import { Plus, X, ExternalLink } from "lucide-react";

const BRANDS = [
  { id: "20e8bb0e-29fd-492e-ad91-2beb239e4b0f", name: "Ash Couture", abbr: "AC", color: "#2C2C2A" },
  { id: "caa9919a-5fe0-4e67-844a-fd75f3170516", name: "Digital Course Agency", abbr: "DCA", color: "#C8432A" },
  { id: "ba48df91-58dc-4471-93f4-1c2a9ba69d35", name: "Digital Expert School", abbr: "DES", color: "#185FA5" },
  { id: "a80ef03f-697b-47da-9c73-81b9b4d2717e", name: "Lux Leisure Lifestyle", abbr: "LLL", color: "#888480" },
  { id: "f4aec731-0842-493e-b17f-56e5265318ac", name: "Opulent Outreach Group", abbr: "OOG", color: "#B89A5A" },
  { id: "41d737ec-4a5a-425c-9f1e-ad509988c3d8", name: "TikTok Digital Income", abbr: "TDI", color: "#534AB7" },
];

const STATUSES = ["Planning", "Warmup", "Launch", "Open Cart", "Closed", "Complete"];

function LaunchModal({ launch, onClose, onSave }: { launch: Partial<Launch> | null; onClose: () => void; onSave: () => void }) {
  const [form, setForm] = useState<Partial<Launch>>(launch || { status: "Planning", revenue_goal: 0, revenue_closed: 0 });
  const [saving, setSaving] = useState(false);
  const set = (k: keyof Launch, v: unknown) => setForm(f => ({ ...f, [k]: v }));

  async function save() {
    setSaving(true);
    if (form.id) await supabase.from("launches").update(form).eq("id", form.id);
    else await supabase.from("launches").insert(form);
    setSaving(false);
    onSave(); onClose();
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{ maxWidth: 580 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div className="font-display" style={{ fontSize: 22 }}>{form.id ? "Edit Launch" : "Plan Launch"}</div>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "#9A9188" }}><X size={18} /></button>
        </div>
        <div style={{ display: "grid", gap: 12 }}>
          <input className="input" placeholder="Launch name *" value={form.name || ""} onChange={e => set("name", e.target.value)} />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Brand</label>
              <select className="input" value={form.brand_id || ""} onChange={e => set("brand_id", e.target.value)}>
                <option value="">—</option>
                {BRANDS.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Status</label>
              <select className="input" value={form.status || "Planning"} onChange={e => set("status", e.target.value)}>
                {STATUSES.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Price $</label>
              <input className="input" type="number" value={form.price || ""} onChange={e => set("price", parseFloat(e.target.value))} />
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Revenue Goal $</label>
              <input className="input" type="number" value={form.revenue_goal || ""} onChange={e => set("revenue_goal", parseFloat(e.target.value))} />
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Revenue Closed $</label>
              <input className="input" type="number" value={form.revenue_closed || ""} onChange={e => set("revenue_closed", parseFloat(e.target.value))} />
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Launch Date</label>
              <input className="input" type="date" value={form.launch_date || ""} onChange={e => set("launch_date", e.target.value)} />
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Warmup Date</label>
              <input className="input" type="date" value={form.warmup_date || ""} onChange={e => set("warmup_date", e.target.value)} />
            </div>
          </div>
          <input className="input" placeholder="Offer description" value={form.offer || ""} onChange={e => set("offer", e.target.value)} />
          <input className="input" placeholder="Target audience" value={form.target_audience || ""} onChange={e => set("target_audience", e.target.value)} />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <input className="input" placeholder="ManyChat keyword" value={form.manychat_keyword || ""} onChange={e => set("manychat_keyword", e.target.value)} />
            <input className="input" placeholder="Landing page URL" value={form.landing_page_url || ""} onChange={e => set("landing_page_url", e.target.value)} />
          </div>
          {/* Phase checklist */}
          <div style={{ background: "#F7F4F0", borderRadius: 8, padding: "12px 16px" }}>
            <div style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", marginBottom: 10 }}>Launch Phases</div>
            {[
              { k: "phase1_complete" as keyof Launch, l: "Phase 1: Warmup & Awareness" },
              { k: "phase2_complete" as keyof Launch, l: "Phase 2: Cart Open & Push" },
              { k: "phase3_complete" as keyof Launch, l: "Phase 3: Urgency & Close" },
              { k: "phase4_complete" as keyof Launch, l: "Phase 4: Debrief & Repurpose" },
            ].map(({ k, l }) => (
              <div key={k} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                <input type="checkbox" id={k} checked={!!form[k]} onChange={e => set(k, e.target.checked)} />
                <label htmlFor={k} style={{ fontSize: 13, color: "#444140", cursor: "pointer" }}>{l}</label>
              </div>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 20, justifyContent: "flex-end" }}>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={saving || !form.name}>{saving ? "Saving..." : "Save Launch"}</button>
        </div>
      </div>
    </div>
  );
}

export default function LaunchesPage() {
  const [launches, setLaunches] = useState<Launch[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<Partial<Launch> | null | false>(false);
  const [filterStatus, setFilterStatus] = useState("");

  async function load() {
    setLoading(true);
    const { data } = await supabase.from("launches").select("*, brand:brands(*)").order("created_at", { ascending: false });
    setLaunches(data || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  const filtered = launches.filter(l => !filterStatus || l.status === filterStatus);
  const totalClosed = launches.reduce((s, l) => s + (l.revenue_closed || 0), 0);
  const totalGoal = launches.reduce((s, l) => s + (l.revenue_goal || 0), 0);

  const STATUS_COLOR: Record<string, string> = {
    Planning: "#EDE8E1", Warmup: "#FEF3C7", Launch: "#DBEAFE",
    "Open Cart": "#D1FAE5", Closed: "#F3F4F6", Complete: "#B89A5A22"
  };

  return (
    <div style={{ maxWidth: 1100, animation: "slideUp 0.4s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
        <div>
          <h1 className="font-display" style={{ fontSize: 34, fontWeight: 400 }}>Launches</h1>
          <div style={{ fontSize: 13, color: "#9A9188", marginTop: 2 }}>{launches.length} launches tracked</div>
        </div>
        <button className="btn btn-primary" onClick={() => setModal({})}>
          <Plus size={14} /> Plan Launch
        </button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 16, marginBottom: 24 }}>
        <div className="card" style={{ borderTop: "3px solid #B89A5A" }}>
          <div style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "#9A9188", marginBottom: 6 }}>Total Revenue Closed</div>
          <div className="font-display" style={{ fontSize: 28 }}>${totalClosed.toLocaleString()}</div>
        </div>
        <div className="card" style={{ borderTop: "3px solid #185FA5" }}>
          <div style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "#9A9188", marginBottom: 6 }}>Total Revenue Goal</div>
          <div className="font-display" style={{ fontSize: 28 }}>${totalGoal.toLocaleString()}</div>
        </div>
        <div className="card" style={{ borderTop: "3px solid #2C2C2A" }}>
          <div style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "#9A9188", marginBottom: 6 }}>Active Launches</div>
          <div className="font-display" style={{ fontSize: 28 }}>{launches.filter(l => ["Warmup","Launch","Open Cart"].includes(l.status || "")).length}</div>
        </div>
      </div>

      <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
        <select className="input" style={{ width: 160 }} value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
          <option value="">All Statuses</option>
          {STATUSES.map(s => <option key={s}>{s}</option>)}
        </select>
      </div>

      {loading ? (
        <div style={{ display: "grid", gap: 12 }}>
          {[1,2,3].map(i => <div key={i} className="skeleton" style={{ height: 100 }} />)}
        </div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: "center", padding: "48px 0" }}>
          <div style={{ fontSize: 13, color: "#9A9188", marginBottom: 12 }}>No launches yet.</div>
          <button className="btn btn-primary" onClick={() => setModal({})}>Plan First Launch</button>
        </div>
      ) : (
        <div style={{ display: "grid", gap: 12 }}>
          {filtered.map(l => {
            const brand = BRANDS.find(b => b.id === l.brand_id);
            const pct = l.revenue_goal && l.revenue_goal > 0 ? Math.min(100, Math.round(((l.revenue_closed || 0) / l.revenue_goal) * 100)) : 0;
            const phases = [l.phase1_complete, l.phase2_complete, l.phase3_complete, l.phase4_complete].filter(Boolean).length;
            return (
              <div key={l.id} className="card" style={{ borderLeft: `4px solid ${brand?.color || "#B89A5A"}` }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
                  <div>
                    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
                      <span style={{ fontSize: 15, fontWeight: 500 }}>{l.name}</span>
                      {brand && <span className="brand-pill" style={{ background: brand.color + "20", color: brand.color }}>{brand.abbr}</span>}
                      <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 100, background: STATUS_COLOR[l.status || "Planning"] || "#EDE8E1", color: "#7D7470" }}>{l.status}</span>
                    </div>
                    {l.offer && <div style={{ fontSize: 12, color: "#9A9188" }}>{l.offer}</div>}
                  </div>
                  <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                    {l.landing_page_url && (
                      <a href={l.landing_page_url} target="_blank" rel="noopener noreferrer" style={{ color: "#9A9188" }}>
                        <ExternalLink size={14} />
                      </a>
                    )}
                    <button onClick={() => setModal(l)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 12, color: "#B89A5A", fontFamily: "var(--font-jost)" }}>Edit</button>
                  </div>
                </div>
                <div style={{ display: "flex", gap: 24, alignItems: "center" }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 12, color: "#9A9188", marginBottom: 4 }}>
                      ${(l.revenue_closed || 0).toLocaleString()} / ${(l.revenue_goal || 0).toLocaleString()} · {pct}%
                    </div>
                    <div className="progress-bar">
                      <div className="progress-fill" style={{ width: `${pct}%`, background: brand?.color || "#B89A5A" }} />
                    </div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 12, color: "#9A9188" }}>Phases</div>
                    <div style={{ fontSize: 13, color: "#444140" }}>{phases}/4</div>
                  </div>
                  {l.launch_date && (
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontSize: 12, color: "#9A9188" }}>Launch Date</div>
                      <div style={{ fontSize: 13 }}>{new Date(l.launch_date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</div>
                    </div>
                  )}
                  {l.manychat_keyword && (
                    <div style={{ padding: "4px 10px", background: "#534AB710", borderRadius: 100, fontSize: 11, color: "#534AB7" }}>
                      DM: {l.manychat_keyword}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {modal !== false && <LaunchModal launch={modal} onClose={() => setModal(false)} onSave={load} />}
    </div>
  );
}
