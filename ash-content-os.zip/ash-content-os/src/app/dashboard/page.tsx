"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import type { WeeklyGoal, QuarterlyGoal, Post, Brand, Launch } from "@/types";
import { TrendingUp, FileText, Lightbulb, Target, Rocket, Zap, ArrowRight } from "lucide-react";
import Link from "next/link";

const BRANDS = [
  { id: "20e8bb0e-29fd-492e-ad91-2beb239e4b0f", name: "Ash Couture", abbr: "AC", color: "#2C2C2A" },
  { id: "caa9919a-5fe0-4e67-844a-fd75f3170516", name: "Digital Course Agency", abbr: "DCA", color: "#C8432A" },
  { id: "ba48df91-58dc-4471-93f4-1c2a9ba69d35", name: "Digital Expert School", abbr: "DES", color: "#185FA5" },
  { id: "a80ef03f-697b-47da-9c73-81b9b4d2717e", name: "Lux Leisure Lifestyle", abbr: "LLL", color: "#888480" },
  { id: "f4aec731-0842-493e-b17f-56e5265318ac", name: "Opulent Outreach Group", abbr: "OOG", color: "#B89A5A" },
  { id: "41d737ec-4a5a-425c-9f1e-ad509988c3d8", name: "TikTok Digital Income", abbr: "TDI", color: "#534AB7" },
];

function StatCard({ label, value, sub, color }: { label: string; value: string | number; sub?: string; color?: string }) {
  return (
    <div className="card" style={{ borderTop: `3px solid ${color || "#B89A5A"}` }}>
      <div style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "#9A9188", marginBottom: 8 }}>{label}</div>
      <div className="font-display" style={{ fontSize: 32, color: "#1A1917", lineHeight: 1 }}>{value}</div>
      {sub && <div style={{ fontSize: 12, color: "#9A9188", marginTop: 6 }}>{sub}</div>}
    </div>
  );
}

function GoalProgress({ label, actual, target, color }: { label: string; actual: number; target: number; color?: string }) {
  const pct = target > 0 ? Math.min(100, Math.round((actual / target) * 100)) : 0;
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4, fontSize: 12 }}>
        <span style={{ color: "#444140" }}>{label}</span>
        <span style={{ color: "#9A9188" }}>{actual} / {target}</span>
      </div>
      <div className="progress-bar">
        <div className="progress-fill" style={{ width: `${pct}%`, background: color || "#B89A5A" }} />
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const [weekly, setWeekly] = useState<WeeklyGoal | null>(null);
  const [quarterly, setQuarterly] = useState<QuarterlyGoal | null>(null);
  const [recentPosts, setRecentPosts] = useState<Post[]>([]);
  const [activeLaunches, setActiveLaunches] = useState<Launch[]>([]);
  const [postCount, setPostCount] = useState(0);
  const [ideaCount, setIdeaCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const [
        { data: wg },
        { data: qg },
        { data: posts },
        { data: launches },
        { count: pc },
        { count: ic },
      ] = await Promise.all([
        supabase.from("weekly_goals").select("*").order("week_of", { ascending: false }).limit(1).maybeSingle(),
        supabase.from("quarterly_goals").select("*").order("year", { ascending: false }).order("quarter", { ascending: false }).limit(1).maybeSingle(),
        supabase.from("posts").select("*, brand:brands(*)").order("created_at", { ascending: false }).limit(5),
        supabase.from("launches").select("*, brand:brands(*)").in("status", ["Planning", "Warmup", "Launch", "Open Cart"]).limit(3),
        supabase.from("posts").select("id", { count: "exact", head: true }),
        supabase.from("ideas").select("id", { count: "exact", head: true }),
      ]);
      setWeekly(wg || null);
      setQuarterly(qg || null);
      setRecentPosts(posts || []);
      setActiveLaunches(launches || []);
      setPostCount(pc || 0);
      setIdeaCount(ic || 0);
      setLoading(false);
    }
    load();
  }, []);

  const today = new Date();
  const greeting = today.getHours() < 12 ? "Good morning" : today.getHours() < 17 ? "Good afternoon" : "Good evening";

  if (loading) return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div className="skeleton" style={{ height: 32, width: 280 }} />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16 }}>
        {[1,2,3,4].map(i => <div key={i} className="skeleton" style={{ height: 100 }} />)}
      </div>
    </div>
  );

  return (
    <div style={{ maxWidth: 1100, animation: "slideUp 0.4s ease" }}>
      {/* Header */}
      <div style={{ marginBottom: 32 }}>
        <div style={{ fontSize: 13, color: "#9A9188", marginBottom: 4 }}>
          {today.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
        </div>
        <h1 className="font-display" style={{ fontSize: 36, color: "#1A1917", fontWeight: 400 }}>
          {greeting}, Ash ✦
        </h1>
        <p style={{ fontSize: 14, color: "#7D7470", marginTop: 4 }}>Your content empire, at a glance.</p>
      </div>

      {/* Top stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 28 }}>
        <StatCard label="Posts Created" value={postCount} color="#B89A5A" />
        <StatCard label="Ideas Banked" value={ideaCount} color="#2C2C2A" />
        <StatCard label="Weekly Revenue" value={weekly ? `$${(weekly.revenue_actual || 0).toLocaleString()}` : "$0"} sub={weekly ? `Goal: $${weekly.revenue_target?.toLocaleString()}` : ""} color="#C8432A" />
        <StatCard label="Posting Streak" value={weekly?.posting_streak ?? 0} sub="days" color="#185FA5" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 20, marginBottom: 20 }}>
        {/* Weekly Goals */}
        <div className="card">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
            <div>
              <div className="font-display" style={{ fontSize: 20 }}>This Week</div>
              {weekly && <div style={{ fontSize: 11, color: "#9A9188", letterSpacing: "0.06em" }}>
                Week of {new Date(weekly.week_of).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
              </div>}
            </div>
            <Link href="/goals" style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 12, color: "#B89A5A", textDecoration: "none" }}>
              View all <ArrowRight size={12} />
            </Link>
          </div>
          {weekly ? (
            <div>
              <GoalProgress label="Ash Couture Posts" actual={weekly.ac_posts_actual} target={weekly.ac_posts_target} color="#2C2C2A" />
              <GoalProgress label="DCA Posts" actual={weekly.dca_posts_actual} target={weekly.dca_posts_target} color="#C8432A" />
              <GoalProgress label="TikTok Posts" actual={weekly.tiktok_posts_actual} target={weekly.tiktok_posts_target} color="#534AB7" />
              <GoalProgress label="Strategy Calls" actual={weekly.strategy_calls_actual} target={weekly.strategy_calls_target} color="#B89A5A" />
              <GoalProgress label="Webinars" actual={weekly.webinars_actual} target={weekly.webinars_target} color="#185FA5" />
            </div>
          ) : (
            <div style={{ textAlign: "center", padding: "24px 0" }}>
              <div style={{ fontSize: 13, color: "#9A9188", marginBottom: 12 }}>No weekly goals set yet.</div>
              <Link href="/goals" className="btn btn-primary" style={{ fontSize: 12 }}>Set Goals</Link>
            </div>
          )}
        </div>

        {/* Q Goals */}
        <div className="card">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
            <div>
              <div className="font-display" style={{ fontSize: 20 }}>Q{quarterly?.quarter ?? "2"} {quarterly?.year ?? 2026}</div>
              <div style={{ fontSize: 11, color: "#9A9188", letterSpacing: "0.06em" }}>Quarterly Targets</div>
            </div>
          </div>
          {quarterly ? (
            <div>
              <GoalProgress label="Revenue" actual={quarterly.revenue_actual} target={quarterly.revenue_target} color="#B89A5A" />
              <GoalProgress label="IG Followers" actual={quarterly.ig_followers_actual} target={quarterly.ig_followers_target} color="#2C2C2A" />
              <GoalProgress label="DCA Clients" actual={quarterly.dca_clients_actual} target={quarterly.dca_clients_target} color="#C8432A" />
              <GoalProgress label="TikTok Followers" actual={quarterly.tiktok_followers_actual} target={quarterly.tiktok_followers_target} color="#534AB7" />
            </div>
          ) : (
            <div style={{ textAlign: "center", padding: "24px 0" }}>
              <div style={{ fontSize: 13, color: "#9A9188", marginBottom: 12 }}>No quarterly goals yet.</div>
              <Link href="/goals" className="btn btn-primary" style={{ fontSize: 12 }}>Set Q Goals</Link>
            </div>
          )}
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 20 }}>
        {/* Recent Posts */}
        <div className="card" style={{ padding: 0, overflow: "hidden" }}>
          <div style={{ padding: "16px 20px", borderBottom: "1px solid #F7F4F0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div className="font-display" style={{ fontSize: 18 }}>Recent Posts</div>
            <Link href="/posts" style={{ fontSize: 12, color: "#B89A5A", textDecoration: "none", display: "flex", alignItems: "center", gap: 4 }}>
              All posts <ArrowRight size={12} />
            </Link>
          </div>
          {recentPosts.length > 0 ? (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Brand</th>
                  <th>Status</th>
                  <th>Platform</th>
                </tr>
              </thead>
              <tbody>
                {recentPosts.map(p => {
                  const brand = BRANDS.find(b => b.id === p.brand_id);
                  return (
                    <tr key={p.id}>
                      <td style={{ maxWidth: 180, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                        {p.title}
                      </td>
                      <td>
                        {brand && (
                          <span className="brand-pill" style={{ background: brand.color + "22", color: brand.color }}>
                            <span style={{ width: 6, height: 6, borderRadius: "50%", background: brand.color, display: "inline-block" }} />
                            {brand.abbr}
                          </span>
                        )}
                      </td>
                      <td>
                        <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 100, background: "#EDE8E1", color: "#7D7470" }}>
                          {p.status}
                        </span>
                      </td>
                      <td style={{ fontSize: 12, color: "#9A9188" }}>{p.platform || "—"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          ) : (
            <div style={{ padding: "32px 20px", textAlign: "center" }}>
              <div style={{ fontSize: 13, color: "#9A9188", marginBottom: 12 }}>No posts yet. Start creating.</div>
              <Link href="/posts" className="btn btn-primary" style={{ fontSize: 12 }}>Add First Post</Link>
            </div>
          )}
        </div>

        {/* Active Launches */}
        <div className="card">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <div className="font-display" style={{ fontSize: 18 }}>Active Launches</div>
            <Link href="/launches" style={{ fontSize: 12, color: "#B89A5A", textDecoration: "none", display: "flex", alignItems: "center", gap: 4 }}>
              All <ArrowRight size={12} />
            </Link>
          </div>
          {activeLaunches.length > 0 ? (
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {activeLaunches.map(l => {
                const brand = BRANDS.find(b => b.id === l.brand_id);
                const pct = l.revenue_goal && l.revenue_goal > 0 ? Math.min(100, Math.round(((l.revenue_closed || 0) / l.revenue_goal) * 100)) : 0;
                return (
                  <div key={l.id} style={{ padding: "12px", background: "#F7F4F0", borderRadius: 8 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                      <div style={{ fontSize: 13, fontWeight: 500 }}>{l.name}</div>
                      {brand && <span className="brand-pill" style={{ background: brand.color + "22", color: brand.color }}>{brand.abbr}</span>}
                    </div>
                    <div style={{ fontSize: 11, color: "#9A9188", marginBottom: 6 }}>
                      ${(l.revenue_closed || 0).toLocaleString()} / ${(l.revenue_goal || 0).toLocaleString()} goal
                    </div>
                    <div className="progress-bar">
                      <div className="progress-fill" style={{ width: `${pct}%`, background: brand?.color || "#B89A5A" }} />
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div style={{ textAlign: "center", padding: "24px 0" }}>
              <div style={{ fontSize: 13, color: "#9A9188", marginBottom: 12 }}>No active launches.</div>
              <Link href="/launches" className="btn btn-primary" style={{ fontSize: 12 }}>Plan a Launch</Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
