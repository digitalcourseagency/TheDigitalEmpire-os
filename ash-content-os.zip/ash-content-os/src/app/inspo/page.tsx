"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import type { Inspo } from "@/types";
import { Plus, X, ExternalLink, Flame } from "lucide-react";

const BRANDS = [
  { id: "20e8bb0e-29fd-492e-ad91-2beb239e4b0f", name: "Ash Couture", abbr: "AC", color: "#2C2C2A" },
  { id: "caa9919a-5fe0-4e67-844a-fd75f3170516", name: "Digital Course Agency", abbr: "DCA", color: "#C8432A" },
  { id: "ba48df91-58dc-4471-93f4-1c2a9ba69d35", name: "Digital Expert School", abbr: "DES", color: "#185FA5" },
  { id: "a80ef03f-697b-47da-9c73-81b9b4d2717e", name: "Lux Leisure Lifestyle", abbr: "LLL", color: "#888480" },
  { id: "f4aec731-0842-493e-b17f-56e5265318ac", name: "Opulent Outreach Group", abbr: "OOG", color: "#B89A5A" },
  { id: "41d737ec-4a5a-425c-9f1e-ad509988c3d8", name: "TikTok Digital Income", abbr: "TDI", color: "#534AB7" },
];

const PLATFORMS = ["Instagram", "TikTok", "YouTube", "Pinterest", "X", "LinkedIn"];
const STATUSES = ["To recreate", "In progress", "Done", "Skipped"];
const PRIORITIES = ["High", "Medium", "Low"];

function InspoModal({ inspo, onClose, onSave }: { inspo: Partial<Inspo> | null; onClose: () => void; onSave: () => void }) {
  const [form, setForm] = useState<Partial<Inspo>>(inspo || { status: "To recreate", priority: "Medium", is_trending: false });
  const [saving, setSaving] = useState(false);
  const set = (k: keyof Inspo, v: unknown) => setForm(f => ({ ...f, [k]: v }));

  async function save() {
    setSaving(true);
    if (form.id) await supabase.from("inspo").update(form).eq("id", form.id);
    else await supabase.from("inspo").insert(form);
    setSaving(false);
    onSave(); onClose();
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div className="font-display" style={{ fontSize: 22 }}>{form.id ? "Edit Inspo" : "Save Inspo"}</div>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "#9A9188" }}><X size={18} /></button>
        </div>
        <div style={{ display: "grid", gap: 12 }}>
          <input className="input" placeholder="Title / description *" value={form.title || ""} onChange={e => set("title", e.target.value)} />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Source Account</label>
              <input className="input" value={form.source_account || ""} onChange={e => set("source_account", e.target.value)} placeholder="@handle" />
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Platform</label>
              <select className="input" value={form.platform || ""} onChange={e => set("platform", e.target.value)}>
                <option value="">—</option>
                {PLATFORMS.map(p => <option key={p}>{p}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Source URL</label>
            <input className="input" value={form.source_url || ""} onChange={e => set("source_url", e.target.value)} placeholder="https://..." />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Brand</label>
              <select className="input" value={form.brand_id || ""} onChange={e => set("brand_id", e.target.value)}>
                <option value="">—</option>
                {BRANDS.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Priority</label>
              <select className="input" value={form.priority || "Medium"} onChange={e => set("priority", e.target.value)}>
                {PRIORITIES.map(p => <option key={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Status</label>
              <select className="input" value={form.status || "To recreate"} onChange={e => set("status", e.target.value)}>
                {STATUSES.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Category</label>
              <input className="input" value={form.category || ""} onChange={e => set("category", e.target.value)} placeholder="Hook style, Format, Aesthetic" />
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Video Format</label>
              <input className="input" value={form.video_format || ""} onChange={e => set("video_format", e.target.value)} placeholder="POV, Talking head, B-roll" />
            </div>
          </div>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Notes</label>
            <textarea className="input" rows={2} value={form.notes || ""} onChange={e => set("notes", e.target.value)} placeholder="Why you saved this, what to steal..." style={{ resize: "vertical" }} />
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <input type="checkbox" id="is_trending" checked={!!form.is_trending} onChange={e => set("is_trending", e.target.checked)} />
            <label htmlFor="is_trending" style={{ fontSize: 13, color: "#444140", cursor: "pointer" }}>🔥 Currently trending</label>
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 20, justifyContent: "flex-end" }}>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={saving || !form.title}>{saving ? "Saving..." : "Save"}</button>
        </div>
      </div>
    </div>
  );
}

export default function InspoPage() {
  const [items, setItems] = useState<Inspo[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<Partial<Inspo> | null | false>(false);
  const [filterPlatform, setFilterPlatform] = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const [filterBrand, setFilterBrand] = useState("");
  const [search, setSearch] = useState("");

  async function load() {
    setLoading(true);
    const { data } = await supabase.from("inspo").select("*").order("created_at", { ascending: false });
    setItems(data || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  const filtered = items.filter(i => {
    if (filterPlatform && i.platform !== filterPlatform) return false;
    if (filterStatus && i.status !== filterStatus) return false;
    if (filterBrand && i.brand_id !== filterBrand) return false;
    if (search && !i.title.toLowerCase().includes(search.toLowerCase()) && !(i.source_account || "").toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const PRIORITY_COLOR: Record<string, string> = { High: "#C8432A", Medium: "#B89A5A", Low: "#9A9188" };
  const STATUS_BG: Record<string, string> = { "To recreate": "#FEF3C7", "In progress": "#DBEAFE", Done: "#D1FAE5", Skipped: "#EDE8E1" };
  const STATUS_TEXT: Record<string, string> = { "To recreate": "#92400E", "In progress": "#1E40AF", Done: "#065F46", Skipped: "#9A9188" };

  return (
    <div style={{ maxWidth: 1100, animation: "slideUp 0.4s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
        <div>
          <h1 className="font-display" style={{ fontSize: 34, fontWeight: 400 }}>Inspo Vault</h1>
          <div style={{ fontSize: 13, color: "#9A9188", marginTop: 2 }}>{items.length} pieces saved · {items.filter(i => i.is_trending).length} trending</div>
        </div>
        <button className="btn btn-primary" onClick={() => setModal({})}><Plus size={14} /> Save Inspo</button>
      </div>

      <div style={{ display: "flex", gap: 10, marginBottom: 20, flexWrap: "wrap" }}>
        <input className="input" style={{ width: 200 }} placeholder="Search..." value={search} onChange={e => setSearch(e.target.value)} />
        <select className="input" style={{ width: 150 }} value={filterPlatform} onChange={e => setFilterPlatform(e.target.value)}>
          <option value="">All Platforms</option>
          {PLATFORMS.map(p => <option key={p}>{p}</option>)}
        </select>
        <select className="input" style={{ width: 150 }} value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
          <option value="">All Statuses</option>
          {STATUSES.map(s => <option key={s}>{s}</option>)}
        </select>
        <select className="input" style={{ width: 160 }} value={filterBrand} onChange={e => setFilterBrand(e.target.value)}>
          <option value="">All Brands</option>
          {BRANDS.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
        </select>
      </div>

      {loading ? (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(280px,1fr))", gap: 12 }}>
          {[1,2,3,4,5,6].map(i => <div key={i} className="skeleton" style={{ height: 130 }} />)}
        </div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: "center", padding: "64px 0" }}>
          <Flame size={32} color="#B8B0A5" style={{ margin: "0 auto 12px" }} />
          <div style={{ fontSize: 13, color: "#9A9188", marginBottom: 12 }}>No inspo saved yet.</div>
          <button className="btn btn-primary" onClick={() => setModal({})}>Save First Inspo</button>
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(280px,1fr))", gap: 12 }}>
          {filtered.map(item => {
            const brand = BRANDS.find(b => b.id === item.brand_id);
            return (
              <div key={item.id} className="card" style={{ borderTop: `3px solid ${PRIORITY_COLOR[item.priority || "Medium"]}` }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
                      {item.is_trending && <span style={{ fontSize: 12 }}>🔥</span>}
                      <span style={{ fontSize: 13, fontWeight: 400, lineHeight: 1.3 }}>{item.title}</span>
                    </div>
                    {item.source_account && <div style={{ fontSize: 11, color: "#9A9188" }}>{item.source_account} {item.platform && `· ${item.platform}`}</div>}
                  </div>
                  <div style={{ display: "flex", gap: 6, marginLeft: 8 }}>
                    {item.source_url && <a href={item.source_url} target="_blank" rel="noopener noreferrer" style={{ color: "#9A9188" }}><ExternalLink size={13} /></a>}
                    <button onClick={() => setModal(item)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 12, color: "#B89A5A", fontFamily: "var(--font-jost)" }}>Edit</button>
                  </div>
                </div>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
                  <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 100, background: STATUS_BG[item.status || "To recreate"] || "#EDE8E1", color: STATUS_TEXT[item.status || "To recreate"] || "#7D7470" }}>
                    {item.status}
                  </span>
                  {brand && <span className="brand-pill" style={{ background: brand.color + "20", color: brand.color }}>{brand.abbr}</span>}
                  {item.video_format && <span style={{ fontSize: 11, color: "#9A9188" }}>{item.video_format}</span>}
                </div>
                {item.notes && <div style={{ fontSize: 12, color: "#7D7470", marginTop: 8, lineHeight: 1.5, borderTop: "1px solid #F7F4F0", paddingTop: 8 }}>{item.notes}</div>}
              </div>
            );
          })}
        </div>
      )}

      {modal !== false && <InspoModal inspo={modal} onClose={() => setModal(false)} onSave={load} />}
    </div>
  );
}
