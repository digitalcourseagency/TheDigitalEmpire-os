"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import type { Keyword } from "@/types";
import { Plus, X, Zap } from "lucide-react";

const BRANDS = [
  { id: "20e8bb0e-29fd-492e-ad91-2beb239e4b0f", name: "Ash Couture", abbr: "AC", color: "#2C2C2A" },
  { id: "caa9919a-5fe0-4e67-844a-fd75f3170516", name: "Digital Course Agency", abbr: "DCA", color: "#C8432A" },
  { id: "ba48df91-58dc-4471-93f4-1c2a9ba69d35", name: "Digital Expert School", abbr: "DES", color: "#185FA5" },
  { id: "a80ef03f-697b-47da-9c73-81b9b4d2717e", name: "Lux Leisure Lifestyle", abbr: "LLL", color: "#888480" },
  { id: "f4aec731-0842-493e-b17f-56e5265318ac", name: "Opulent Outreach Group", abbr: "OOG", color: "#B89A5A" },
  { id: "41d737ec-4a5a-425c-9f1e-ad509988c3d8", name: "TikTok Digital Income", abbr: "TDI", color: "#534AB7" },
];

function KwModal({ kw, onClose, onSave }: { kw: Partial<Keyword> | null; onClose: () => void; onSave: () => void }) {
  const [form, setForm] = useState<Partial<Keyword>>(kw || { active: true, triggers_this_week: 0, triggers_total: 0 });
  const [saving, setSaving] = useState(false);
  const set = (k: keyof Keyword, v: unknown) => setForm(f => ({ ...f, [k]: v }));

  async function save() {
    setSaving(true);
    if (form.id) await supabase.from("keywords").update(form).eq("id", form.id);
    else await supabase.from("keywords").insert(form);
    setSaving(false);
    onSave(); onClose();
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div className="font-display" style={{ fontSize: 22 }}>{form.id ? "Edit Keyword" : "Add Keyword"}</div>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "#9A9188" }}><X size={18} /></button>
        </div>
        <div style={{ display: "grid", gap: 12 }}>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Keyword *</label>
            <input className="input" value={form.keyword || ""} onChange={e => set("keyword", e.target.value)} placeholder="e.g. DIGITAL STREAM, CEO" />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Brand</label>
              <select className="input" value={form.brand_id || ""} onChange={e => set("brand_id", e.target.value)}>
                <option value="">—</option>
                {BRANDS.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Destination</label>
              <input className="input" value={form.destination || ""} onChange={e => set("destination", e.target.value)} placeholder="e.g. Webinar signup" />
            </div>
          </div>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Destination URL</label>
            <input className="input" value={form.destination_url || ""} onChange={e => set("destination_url", e.target.value)} placeholder="https://..." />
          </div>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Purpose</label>
            <input className="input" value={form.purpose || ""} onChange={e => set("purpose", e.target.value)} placeholder="What does this keyword trigger?" />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Triggers This Week</label>
              <input className="input" type="number" value={form.triggers_this_week || 0} onChange={e => set("triggers_this_week", parseInt(e.target.value))} />
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Total Triggers</label>
              <input className="input" type="number" value={form.triggers_total || 0} onChange={e => set("triggers_total", parseInt(e.target.value))} />
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <input type="checkbox" id="active" checked={!!form.active} onChange={e => set("active", e.target.checked)} />
            <label htmlFor="active" style={{ fontSize: 13, color: "#444140", cursor: "pointer" }}>Active keyword</label>
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 20, justifyContent: "flex-end" }}>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={saving || !form.keyword}>
            {saving ? "Saving..." : "Save"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function KeywordsPage() {
  const [keywords, setKeywords] = useState<Keyword[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<Partial<Keyword> | null | false>(false);

  async function load() {
    setLoading(true);
    const { data } = await supabase.from("keywords").select("*, brand:brands(*)").order("triggers_total", { ascending: false });
    setKeywords(data || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function toggle(kw: Keyword) {
    await supabase.from("keywords").update({ active: !kw.active }).eq("id", kw.id);
    load();
  }

  const totalTriggersThisWeek = keywords.reduce((s, k) => s + (k.triggers_this_week || 0), 0);
  const totalTriggersAll = keywords.reduce((s, k) => s + (k.triggers_total || 0), 0);

  return (
    <div style={{ maxWidth: 900, animation: "slideUp 0.4s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
        <div>
          <h1 className="font-display" style={{ fontSize: 34, fontWeight: 400 }}>ManyChat Keywords</h1>
          <div style={{ fontSize: 13, color: "#9A9188", marginTop: 2 }}>{keywords.filter(k => k.active).length} active · {keywords.length} total</div>
        </div>
        <button className="btn btn-primary" onClick={() => setModal({})}>
          <Plus size={14} /> Add Keyword
        </button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 16, marginBottom: 24 }}>
        <div className="card" style={{ borderTop: "3px solid #B89A5A" }}>
          <div style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "#9A9188", marginBottom: 6 }}>Active Keywords</div>
          <div className="font-display" style={{ fontSize: 28 }}>{keywords.filter(k => k.active).length}</div>
        </div>
        <div className="card" style={{ borderTop: "3px solid #534AB7" }}>
          <div style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "#9A9188", marginBottom: 6 }}>Triggers This Week</div>
          <div className="font-display" style={{ fontSize: 28 }}>{totalTriggersThisWeek.toLocaleString()}</div>
        </div>
        <div className="card" style={{ borderTop: "3px solid #2C2C2A" }}>
          <div style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "#9A9188", marginBottom: 6 }}>Total Triggers</div>
          <div className="font-display" style={{ fontSize: 28 }}>{totalTriggersAll.toLocaleString()}</div>
        </div>
      </div>

      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        {loading ? (
          <div style={{ padding: 24 }}>{[1,2,3,4].map(i => <div key={i} className="skeleton" style={{ height: 40, marginBottom: 8 }} />)}</div>
        ) : keywords.length === 0 ? (
          <div style={{ textAlign: "center", padding: "48px 0" }}>
            <Zap size={32} color="#B8B0A5" style={{ margin: "0 auto 12px" }} />
            <div style={{ fontSize: 13, color: "#9A9188", marginBottom: 12 }}>No keywords yet.</div>
            <button className="btn btn-primary" onClick={() => setModal({})}>Add First Keyword</button>
          </div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Keyword</th>
                <th>Brand</th>
                <th>Destination</th>
                <th>This Week</th>
                <th>Total</th>
                <th>Status</th>
                <th style={{ textAlign: "right" }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {keywords.map(kw => {
                const brand = BRANDS.find(b => b.id === kw.brand_id);
                return (
                  <tr key={kw.id}>
                    <td><strong style={{ fontWeight: 500, fontSize: 13 }}>{kw.keyword}</strong></td>
                    <td>
                      {brand && <span className="brand-pill" style={{ background: brand.color + "20", color: brand.color }}>{brand.abbr}</span>}
                    </td>
                    <td style={{ fontSize: 12, color: "#7D7470", maxWidth: 180, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                      {kw.destination || "—"}
                    </td>
                    <td style={{ fontSize: 13, color: "#444140" }}>{(kw.triggers_this_week || 0).toLocaleString()}</td>
                    <td style={{ fontSize: 13, color: "#444140" }}>{(kw.triggers_total || 0).toLocaleString()}</td>
                    <td>
                      <button onClick={() => toggle(kw)} style={{
                        fontSize: 11, padding: "3px 10px", borderRadius: 100, border: "none", cursor: "pointer",
                        background: kw.active ? "#D1FAE5" : "#EDE8E1",
                        color: kw.active ? "#065F46" : "#9A9188",
                        fontFamily: "var(--font-jost)"
                      }}>{kw.active ? "Active" : "Inactive"}</button>
                    </td>
                    <td>
                      <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
                        <button onClick={() => setModal(kw)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 12, color: "#B89A5A", fontFamily: "var(--font-jost)" }}>Edit</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {modal !== false && <KwModal kw={modal} onClose={() => setModal(false)} onSave={load} />}
    </div>
  );
}
