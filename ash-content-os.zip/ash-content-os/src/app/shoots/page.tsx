"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { Plus, X, Camera } from "lucide-react";

interface Shoot {
  id: string;
  name: string;
  shoot_date: string | null;
  theme: string | null;
  location: string | null;
  brands_covered: string | null;
  num_looks: number | null;
  shot_list: string | null;
  content_output_goal: string | null;
  photographer: string | null;
  status: string | null;
  is_vault_mining: boolean | null;
  created_at: string;
}

interface Look {
  id: string;
  shoot_id: string | null;
  look_number: number | null;
  outfit_description: string | null;
  color_palette: string | null;
  hair_style: string | null;
  makeup_vibe: string | null;
  brand_content_for: string | null;
  moodboard_links: string | null;
  created_at: string;
}

const STATUSES = ["Planned", "Confirmed", "Shooting", "Editing", "Complete"];

function ShootModal({ shoot, onClose, onSave }: { shoot: Partial<Shoot> | null; onClose: () => void; onSave: () => void }) {
  const [form, setForm] = useState<Partial<Shoot>>(shoot || { status: "Planned", num_looks: 1, is_vault_mining: false });
  const [saving, setSaving] = useState(false);
  const set = (k: keyof Shoot, v: unknown) => setForm(f => ({ ...f, [k]: v }));

  async function save() {
    setSaving(true);
    if (form.id) await supabase.from("shoots").update(form).eq("id", form.id);
    else await supabase.from("shoots").insert(form);
    setSaving(false);
    onSave(); onClose();
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{ maxWidth: 580 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div className="font-display" style={{ fontSize: 22 }}>{form.id ? "Edit Shoot" : "Plan Shoot"}</div>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "#9A9188" }}><X size={18} /></button>
        </div>
        <div style={{ display: "grid", gap: 12 }}>
          <input className="input" placeholder="Shoot name *" value={form.name || ""} onChange={e => set("name", e.target.value)} />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Date</label>
              <input className="input" type="date" value={form.shoot_date || ""} onChange={e => set("shoot_date", e.target.value)} />
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Status</label>
              <select className="input" value={form.status || "Planned"} onChange={e => set("status", e.target.value)}>
                {STATUSES.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}># Looks</label>
              <input className="input" type="number" value={form.num_looks || 1} onChange={e => set("num_looks", parseInt(e.target.value))} />
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Theme</label>
              <input className="input" value={form.theme || ""} onChange={e => set("theme", e.target.value)} placeholder="e.g. NYC Power Move, Soft Luxury" />
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Location</label>
              <input className="input" value={form.location || ""} onChange={e => set("location", e.target.value)} placeholder="Studio, NYC rooftop, etc." />
            </div>
          </div>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Brands Covered</label>
            <input className="input" value={form.brands_covered || ""} onChange={e => set("brands_covered", e.target.value)} placeholder="e.g. AC, DCA, LLL" />
          </div>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Photographer</label>
            <input className="input" value={form.photographer || ""} onChange={e => set("photographer", e.target.value)} />
          </div>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Content Output Goal</label>
            <textarea className="input" rows={2} value={form.content_output_goal || ""} onChange={e => set("content_output_goal", e.target.value)} placeholder="e.g. 60 images, 12 reels, 3 promo videos" style={{ resize: "vertical" }} />
          </div>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Shot List</label>
            <textarea className="input" rows={3} value={form.shot_list || ""} onChange={e => set("shot_list", e.target.value)} placeholder="List of required shots..." style={{ resize: "vertical" }} />
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <input type="checkbox" id="vault" checked={!!form.is_vault_mining} onChange={e => set("is_vault_mining", e.target.checked)} />
            <label htmlFor="vault" style={{ fontSize: 13, cursor: "pointer" }}>🗃️ Vault mining session (repurposing existing content)</label>
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 20, justifyContent: "flex-end" }}>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={saving || !form.name}>{saving ? "Saving..." : "Save Shoot"}</button>
        </div>
      </div>
    </div>
  );
}

export default function ShootsPage() {
  const [shoots, setShoots] = useState<Shoot[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<Partial<Shoot> | null | false>(false);
  const [filterStatus, setFilterStatus] = useState("");

  async function load() {
    setLoading(true);
    const { data } = await supabase.from("shoots").select("*").order("shoot_date", { ascending: true });
    setShoots(data || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  const filtered = shoots.filter(s => !filterStatus || s.status === filterStatus);

  const STATUS_COLOR: Record<string, string> = {
    Planned: "#EDE8E1", Confirmed: "#FEF3C7", Shooting: "#DBEAFE",
    Editing: "#E0E7FF", Complete: "#D1FAE5"
  };

  const upcoming = filtered.filter(s => s.shoot_date && new Date(s.shoot_date) >= new Date() && s.status !== "Complete");
  const past = filtered.filter(s => !upcoming.includes(s));

  return (
    <div style={{ maxWidth: 1000, animation: "slideUp 0.4s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
        <div>
          <h1 className="font-display" style={{ fontSize: 34, fontWeight: 400 }}>Content Shoots</h1>
          <div style={{ fontSize: 13, color: "#9A9188", marginTop: 2 }}>{upcoming.length} upcoming · {shoots.filter(s => s.status === "Complete").length} complete</div>
        </div>
        <button className="btn btn-primary" onClick={() => setModal({})}><Plus size={14} /> Plan Shoot</button>
      </div>

      <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
        <select className="input" style={{ width: 150 }} value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
          <option value="">All Statuses</option>
          {STATUSES.map(s => <option key={s}>{s}</option>)}
        </select>
      </div>

      {loading ? (
        <div style={{ display: "grid", gap: 12 }}>{[1,2,3].map(i => <div key={i} className="skeleton" style={{ height: 100 }} />)}</div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: "center", padding: "64px 0" }}>
          <Camera size={32} color="#B8B0A5" style={{ margin: "0 auto 12px" }} />
          <div style={{ fontSize: 13, color: "#9A9188", marginBottom: 12 }}>No shoots planned yet.</div>
          <button className="btn btn-primary" onClick={() => setModal({})}>Plan First Shoot</button>
        </div>
      ) : (
        <div>
          {upcoming.length > 0 && (
            <div style={{ marginBottom: 24 }}>
              <div style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "#9A9188", marginBottom: 12 }}>Upcoming</div>
              <div style={{ display: "grid", gap: 12 }}>
                {upcoming.map(shoot => (
                  <div key={shoot.id} className="card" style={{ borderLeft: `4px solid #B89A5A` }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                      <div>
                        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
                          <span style={{ fontSize: 15, fontWeight: 500 }}>{shoot.name}</span>
                          {shoot.is_vault_mining && <span style={{ fontSize: 11, color: "#9A9188" }}>🗃️ Vault</span>}
                          <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 100, background: STATUS_COLOR[shoot.status || "Planned"] || "#EDE8E1", color: "#7D7470" }}>{shoot.status}</span>
                        </div>
                        <div style={{ display: "flex", gap: 16, fontSize: 12, color: "#9A9188" }}>
                          {shoot.shoot_date && <span>📅 {new Date(shoot.shoot_date).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}</span>}
                          {shoot.location && <span>📍 {shoot.location}</span>}
                          {shoot.num_looks && <span>👗 {shoot.num_looks} look{shoot.num_looks > 1 ? "s" : ""}</span>}
                          {shoot.photographer && <span>📸 {shoot.photographer}</span>}
                        </div>
                        {shoot.theme && <div style={{ fontSize: 12, color: "#7D7470", marginTop: 4 }}>Theme: {shoot.theme}</div>}
                        {shoot.content_output_goal && <div style={{ fontSize: 12, color: "#7D7470", marginTop: 2 }}>Goal: {shoot.content_output_goal}</div>}
                      </div>
                      <button onClick={() => setModal(shoot)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 12, color: "#B89A5A", fontFamily: "var(--font-jost)" }}>Edit</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {past.length > 0 && (
            <div>
              <div style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "#9A9188", marginBottom: 12 }}>Past Shoots</div>
              <div className="card" style={{ padding: 0, overflow: "hidden" }}>
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Date</th>
                      <th>Theme</th>
                      <th>Looks</th>
                      <th>Status</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {past.map(s => (
                      <tr key={s.id}>
                        <td style={{ fontSize: 13, fontWeight: 400 }}>{s.name}</td>
                        <td style={{ fontSize: 12, color: "#9A9188" }}>{s.shoot_date ? new Date(s.shoot_date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "—"}</td>
                        <td style={{ fontSize: 12, color: "#7D7470" }}>{s.theme || "—"}</td>
                        <td style={{ fontSize: 12 }}>{s.num_looks || 1}</td>
                        <td>
                          <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 100, background: STATUS_COLOR[s.status || "Planned"] || "#EDE8E1", color: "#7D7470" }}>{s.status}</span>
                        </td>
                        <td><button onClick={() => setModal(s)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 12, color: "#B89A5A", fontFamily: "var(--font-jost)" }}>Edit</button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {modal !== false && <ShootModal shoot={modal} onClose={() => setModal(false)} onSave={load} />}
    </div>
  );
}
