"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import type { Analytics } from "@/types";
import { Plus, X } from "lucide-react";

const BRANDS = [
  { id: "20e8bb0e-29fd-492e-ad91-2beb239e4b0f", name: "Ash Couture", abbr: "AC", color: "#2C2C2A" },
  { id: "caa9919a-5fe0-4e67-844a-fd75f3170516", name: "Digital Course Agency", abbr: "DCA", color: "#C8432A" },
  { id: "ba48df91-58dc-4471-93f4-1c2a9ba69d35", name: "Digital Expert School", abbr: "DES", color: "#185FA5" },
  { id: "a80ef03f-697b-47da-9c73-81b9b4d2717e", name: "Lux Leisure Lifestyle", abbr: "LLL", color: "#888480" },
  { id: "f4aec731-0842-493e-b17f-56e5265318ac", name: "Opulent Outreach Group", abbr: "OOG", color: "#B89A5A" },
  { id: "41d737ec-4a5a-425c-9f1e-ad509988c3d8", name: "TikTok Digital Income", abbr: "TDI", color: "#534AB7" },
];

function AModal({ entry, onClose, onSave }: { entry: Partial<Analytics> | null; onClose: () => void; onSave: () => void }) {
  const today = new Date();
  const monday = new Date(today);
  monday.setDate(today.getDate() - today.getDay() + 1);
  const [form, setForm] = useState<Partial<Analytics>>(entry || { week_of: monday.toISOString().split("T")[0], revenue_total: 0, stan_store_revenue: 0 });
  const [saving, setSaving] = useState(false);
  const set = (k: keyof Analytics, v: unknown) => setForm(f => ({ ...f, [k]: v }));
  const num = (k: keyof Analytics) => (e: React.ChangeEvent<HTMLInputElement>) => set(k, e.target.value ? Number(e.target.value) : null);

  async function save() {
    setSaving(true);
    if (form.id) await supabase.from("analytics").update(form).eq("id", form.id);
    else await supabase.from("analytics").insert(form);
    setSaving(false);
    onSave(); onClose();
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{ maxWidth: 580 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div className="font-display" style={{ fontSize: 22 }}>Weekly Analytics</div>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "#9A9188" }}><X size={18} /></button>
        </div>
        <div style={{ display: "grid", gap: 12 }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Week of</label>
              <input className="input" type="date" value={form.week_of || ""} onChange={e => set("week_of", e.target.value)} />
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Brand</label>
              <select className="input" value={form.brand_id || ""} onChange={e => set("brand_id", e.target.value)}>
                <option value="">All / General</option>
                {BRANDS.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
          </div>
          <div style={{ fontSize: 12, fontWeight: 500, letterSpacing: "0.06em", textTransform: "uppercase", color: "#9A9188", marginBottom: -4 }}>Instagram</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
            <div>
              <label style={{ fontSize: 11, color: "#9A9188", display: "block", marginBottom: 3 }}>Followers</label>
              <input className="input" type="number" value={form.ig_followers || ""} onChange={num("ig_followers")} />
            </div>
            <div>
              <label style={{ fontSize: 11, color: "#9A9188", display: "block", marginBottom: 3 }}>Growth</label>
              <input className="input" type="number" value={form.ig_follower_growth || ""} onChange={num("ig_follower_growth")} />
            </div>
            <div>
              <label style={{ fontSize: 11, color: "#9A9188", display: "block", marginBottom: 3 }}>Best Reel Views</label>
              <input className="input" type="number" value={form.best_reel_views || ""} onChange={num("best_reel_views")} />
            </div>
            <div>
              <label style={{ fontSize: 11, color: "#9A9188", display: "block", marginBottom: 3 }}>Profile Visits</label>
              <input className="input" type="number" value={form.profile_visits || ""} onChange={num("profile_visits")} />
            </div>
            <div>
              <label style={{ fontSize: 11, color: "#9A9188", display: "block", marginBottom: 3 }}>Link Clicks</label>
              <input className="input" type="number" value={form.link_bio_clicks || ""} onChange={num("link_bio_clicks")} />
            </div>
            <div>
              <label style={{ fontSize: 11, color: "#9A9188", display: "block", marginBottom: 3 }}>ManyChat DMs</label>
              <input className="input" type="number" value={form.manychat_dms || ""} onChange={num("manychat_dms")} />
            </div>
          </div>
          <div style={{ fontSize: 12, fontWeight: 500, letterSpacing: "0.06em", textTransform: "uppercase", color: "#9A9188", marginBottom: -4 }}>TikTok & YouTube</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <div>
              <label style={{ fontSize: 11, color: "#9A9188", display: "block", marginBottom: 3 }}>TikTok Views</label>
              <input className="input" type="number" value={form.tiktok_views || ""} onChange={num("tiktok_views")} />
            </div>
            <div>
              <label style={{ fontSize: 11, color: "#9A9188", display: "block", marginBottom: 3 }}>YouTube Views</label>
              <input className="input" type="number" value={form.youtube_views || ""} onChange={num("youtube_views")} />
            </div>
          </div>
          <div style={{ fontSize: 12, fontWeight: 500, letterSpacing: "0.06em", textTransform: "uppercase", color: "#9A9188", marginBottom: -4 }}>Revenue & Sales</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
            <div>
              <label style={{ fontSize: 11, color: "#9A9188", display: "block", marginBottom: 3 }}>Total Revenue $</label>
              <input className="input" type="number" value={form.revenue_total || ""} onChange={num("revenue_total")} />
            </div>
            <div>
              <label style={{ fontSize: 11, color: "#9A9188", display: "block", marginBottom: 3 }}>Stan Store $</label>
              <input className="input" type="number" value={form.stan_store_revenue || ""} onChange={num("stan_store_revenue")} />
            </div>
            <div>
              <label style={{ fontSize: 11, color: "#9A9188", display: "block", marginBottom: 3 }}>Strategy Calls Booked</label>
              <input className="input" type="number" value={form.strategy_calls_booked || ""} onChange={num("strategy_calls_booked")} />
            </div>
          </div>
          <div>
            <label style={{ fontSize: 11, color: "#9A9188", display: "block", marginBottom: 3 }}>Best Post</label>
            <input className="input" value={form.best_post || ""} onChange={e => set("best_post", e.target.value)} placeholder="What performed best?" />
          </div>
          <div>
            <label style={{ fontSize: 11, color: "#9A9188", display: "block", marginBottom: 3 }}>Top Insight</label>
            <textarea className="input" rows={2} value={form.top_insight || ""} onChange={e => set("top_insight", e.target.value)} placeholder="What did you learn?" style={{ resize: "vertical" }} />
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 20, justifyContent: "flex-end" }}>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={saving}>{saving ? "Saving..." : "Save"}</button>
        </div>
      </div>
    </div>
  );
}

export default function AnalyticsPage() {
  const [entries, setEntries] = useState<Analytics[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<Partial<Analytics> | null | false>(false);
  const [filterBrand, setFilterBrand] = useState("");

  async function load() {
    setLoading(true);
    const { data } = await supabase.from("analytics").select("*, brand:brands(*)").order("week_of", { ascending: false });
    setEntries(data || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  const filtered = entries.filter(e => !filterBrand || e.brand_id === filterBrand);
  const latest = filtered[0];

  return (
    <div style={{ maxWidth: 1100, animation: "slideUp 0.4s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 28 }}>
        <div>
          <h1 className="font-display" style={{ fontSize: 34, fontWeight: 400 }}>Analytics</h1>
          <div style={{ fontSize: 13, color: "#9A9188", marginTop: 2 }}>Weekly performance tracking</div>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <select className="input" style={{ width: 160 }} value={filterBrand} onChange={e => setFilterBrand(e.target.value)}>
            <option value="">All Brands</option>
            {BRANDS.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
          <button className="btn btn-primary" onClick={() => setModal({})}><Plus size={14} /> Log Week</button>
        </div>
      </div>

      {/* Latest snapshot */}
      {latest && (
        <div className="card" style={{ marginBottom: 24 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
            <div>
              <div className="font-display" style={{ fontSize: 20 }}>Latest Snapshot</div>
              <div style={{ fontSize: 12, color: "#9A9188" }}>Week of {new Date(latest.week_of).toLocaleDateString("en-US", { month: "long", day: "numeric" })}</div>
            </div>
            <button onClick={() => setModal(latest)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 12, color: "#B89A5A", fontFamily: "var(--font-jost)" }}>Edit</button>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(6,1fr)", gap: 16 }}>
            {[
              { label: "IG Followers", value: latest.ig_followers?.toLocaleString() || "—", color: "#2C2C2A" },
              { label: "IG Growth", value: latest.ig_follower_growth ? `+${latest.ig_follower_growth}` : "—", color: "#2C2C2A" },
              { label: "Best Reel", value: latest.best_reel_views?.toLocaleString() || "—", color: "#C8432A" },
              { label: "TikTok Views", value: latest.tiktok_views?.toLocaleString() || "—", color: "#534AB7" },
              { label: "ManyChat DMs", value: latest.manychat_dms?.toLocaleString() || "—", color: "#B89A5A" },
              { label: "Revenue", value: latest.revenue_total ? `$${latest.revenue_total.toLocaleString()}` : "—", color: "#B89A5A" },
            ].map(stat => (
              <div key={stat.label} style={{ textAlign: "center" }}>
                <div style={{ fontSize: 22, fontFamily: "var(--font-cormorant)", color: stat.color }}>{stat.value}</div>
                <div style={{ fontSize: 10, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", marginTop: 2 }}>{stat.label}</div>
              </div>
            ))}
          </div>
          {latest.best_post && (
            <div style={{ marginTop: 12, padding: "10px 14px", background: "#F7F4F0", borderRadius: 8, fontSize: 12, color: "#444140" }}>
              ⭐ Best post: {latest.best_post}
            </div>
          )}
        </div>
      )}

      {/* History table */}
      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        {loading ? (
          <div style={{ padding: 24 }}>{[1,2,3].map(i => <div key={i} className="skeleton" style={{ height: 40, marginBottom: 8 }} />)}</div>
        ) : filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: "48px 0" }}>
            <div style={{ fontSize: 13, color: "#9A9188", marginBottom: 12 }}>No analytics logged yet.</div>
            <button className="btn btn-primary" onClick={() => setModal({})}>Log First Week</button>
          </div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Week</th>
                <th>Brand</th>
                <th>IG Followers</th>
                <th>Growth</th>
                <th>Best Reel</th>
                <th>TikTok Views</th>
                <th>ManyChat DMs</th>
                <th>Revenue</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(e => {
                const brand = BRANDS.find(b => b.id === e.brand_id);
                return (
                  <tr key={e.id}>
                    <td style={{ fontSize: 12 }}>{new Date(e.week_of).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</td>
                    <td>{brand ? <span className="brand-pill" style={{ background: brand.color + "20", color: brand.color }}>{brand.abbr}</span> : <span style={{ color: "#9A9188", fontSize: 12 }}>All</span>}</td>
                    <td style={{ fontSize: 12 }}>{e.ig_followers?.toLocaleString() || "—"}</td>
                    <td style={{ fontSize: 12, color: (e.ig_follower_growth || 0) > 0 ? "#065F46" : "#9A9188" }}>{e.ig_follower_growth ? `+${e.ig_follower_growth}` : "—"}</td>
                    <td style={{ fontSize: 12 }}>{e.best_reel_views?.toLocaleString() || "—"}</td>
                    <td style={{ fontSize: 12 }}>{e.tiktok_views?.toLocaleString() || "—"}</td>
                    <td style={{ fontSize: 12 }}>{e.manychat_dms?.toLocaleString() || "—"}</td>
                    <td style={{ fontSize: 12, fontWeight: 500 }}>{e.revenue_total ? `$${e.revenue_total.toLocaleString()}` : "—"}</td>
                    <td><button onClick={() => setModal(e)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 12, color: "#B89A5A", fontFamily: "var(--font-jost)" }}>Edit</button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {modal !== false && <AModal entry={modal} onClose={() => setModal(false)} onSave={load} />}
    </div>
  );
}
