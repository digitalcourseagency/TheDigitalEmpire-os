"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import type { Post, Brand } from "@/types";
import { Plus, X, ExternalLink, Star } from "lucide-react";

const BRANDS = [
  { id: "20e8bb0e-29fd-492e-ad91-2beb239e4b0f", name: "Ash Couture", abbr: "AC", color: "#2C2C2A" },
  { id: "caa9919a-5fe0-4e67-844a-fd75f3170516", name: "Digital Course Agency", abbr: "DCA", color: "#C8432A" },
  { id: "ba48df91-58dc-4471-93f4-1c2a9ba69d35", name: "Digital Expert School", abbr: "DES", color: "#185FA5" },
  { id: "a80ef03f-697b-47da-9c73-81b9b4d2717e", name: "Lux Leisure Lifestyle", abbr: "LLL", color: "#888480" },
  { id: "f4aec731-0842-493e-b17f-56e5265318ac", name: "Opulent Outreach Group", abbr: "OOG", color: "#B89A5A" },
  { id: "41d737ec-4a5a-425c-9f1e-ad509988c3d8", name: "TikTok Digital Income", abbr: "TDI", color: "#534AB7" },
];

const STATUSES = ["Idea", "Scripted", "Filmed", "Edited", "Scheduled", "Live"];
const PLATFORMS = ["Instagram", "TikTok", "YouTube", "Substack", "Facebook", "LinkedIn"];
const CONTENT_TYPES = ["Reel", "Carousel", "Static", "Story", "Live", "YouTube Long", "Short", "Blog/Newsletter"];

const STATUS_COLORS: Record<string, string> = {
  Idea: "#EDE8E1", Scripted: "#FEF3C7", Filmed: "#DBEAFE",
  Edited: "#E0E7FF", Scheduled: "#D1FAE5", Live: "#B89A5A22"
};
const STATUS_TEXT: Record<string, string> = {
  Idea: "#7D7470", Scripted: "#92400E", Filmed: "#1E40AF",
  Edited: "#3730A3", Scheduled: "#065F46", Live: "#7A6535"
};

function PostModal({ post, onClose, onSave }: { post: Partial<Post> | null; onClose: () => void; onSave: () => void }) {
  const [form, setForm] = useState<Partial<Post>>(post || {
    status: "Idea", top_performer: false, revenue_attributed: 0
  });
  const [saving, setSaving] = useState(false);

  const set = (k: keyof Post, v: unknown) => setForm(f => ({ ...f, [k]: v }));

  async function save() {
    setSaving(true);
    if (form.id) {
      await supabase.from("posts").update(form).eq("id", form.id);
    } else {
      await supabase.from("posts").insert(form);
    }
    setSaving(false);
    onSave();
    onClose();
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{ maxWidth: 620 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div className="font-display" style={{ fontSize: 22 }}>{form.id ? "Edit Post" : "New Post"}</div>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "#9A9188" }}><X size={18} /></button>
        </div>

        <div style={{ display: "grid", gap: 14 }}>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Title *</label>
            <input className="input" value={form.title || ""} onChange={e => set("title", e.target.value)} placeholder="Post title or concept..." />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Brand</label>
              <select className="input" value={form.brand_id || ""} onChange={e => set("brand_id", e.target.value)}>
                <option value="">— Select Brand —</option>
                {BRANDS.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Status</label>
              <select className="input" value={form.status || "Idea"} onChange={e => set("status", e.target.value)}>
                {STATUSES.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Platform</label>
              <select className="input" value={form.platform || ""} onChange={e => set("platform", e.target.value)}>
                <option value="">—</option>
                {PLATFORMS.map(p => <option key={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Content Type</label>
              <select className="input" value={form.content_type || ""} onChange={e => set("content_type", e.target.value)}>
                <option value="">—</option>
                {CONTENT_TYPES.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
          </div>

          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Hook</label>
            <input className="input" value={form.hook || ""} onChange={e => set("hook", e.target.value)} placeholder="Opening line that stops the scroll..." />
          </div>

          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Caption</label>
            <textarea className="input" rows={3} value={form.caption || ""} onChange={e => set("caption", e.target.value)} placeholder="Full caption..." style={{ resize: "vertical" }} />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Topic</label>
              <input className="input" value={form.topic || ""} onChange={e => set("topic", e.target.value)} placeholder="e.g. Branding, Money, NYC Life" />
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Publish Date</label>
              <input className="input" type="date" value={form.publish_date || ""} onChange={e => set("publish_date", e.target.value)} />
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>ManyChat Keyword</label>
              <input className="input" value={form.manychat_keyword || ""} onChange={e => set("manychat_keyword", e.target.value)} />
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>CTA Keyword</label>
              <input className="input" value={form.cta_keyword || ""} onChange={e => set("cta_keyword", e.target.value)} />
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Views</label>
              <input className="input" type="number" value={form.views || ""} onChange={e => set("views", parseInt(e.target.value))} />
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Saves</label>
              <input className="input" type="number" value={form.saves || ""} onChange={e => set("saves", parseInt(e.target.value))} />
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Revenue $</label>
              <input className="input" type="number" value={form.revenue_attributed || ""} onChange={e => set("revenue_attributed", parseFloat(e.target.value))} />
            </div>
          </div>

          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Drive Link</label>
            <input className="input" value={form.drive_link || ""} onChange={e => set("drive_link", e.target.value)} placeholder="https://drive.google.com/..." />
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <input type="checkbox" id="top_performer" checked={!!form.top_performer} onChange={e => set("top_performer", e.target.checked)} />
            <label htmlFor="top_performer" style={{ fontSize: 13, color: "#444140", cursor: "pointer" }}>⭐ Mark as Top Performer</label>
          </div>
        </div>

        <div style={{ display: "flex", gap: 10, marginTop: 20, justifyContent: "flex-end" }}>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={saving || !form.title}>
            {saving ? "Saving..." : "Save Post"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function PostsPage() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<Partial<Post> | null | false>(false);
  const [filterBrand, setFilterBrand] = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const [filterPlatform, setFilterPlatform] = useState("");
  const [search, setSearch] = useState("");

  async function load() {
    setLoading(true);
    const { data } = await supabase.from("posts").select("*, brand:brands(*)").order("created_at", { ascending: false });
    setPosts(data || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function deletePost(id: string) {
    if (!confirm("Delete this post?")) return;
    await supabase.from("posts").delete().eq("id", id);
    load();
  }

  const filtered = posts.filter(p => {
    if (filterBrand && p.brand_id !== filterBrand) return false;
    if (filterStatus && p.status !== filterStatus) return false;
    if (filterPlatform && p.platform !== filterPlatform) return false;
    if (search && !p.title.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <div style={{ maxWidth: 1100, animation: "slideUp 0.4s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 28 }}>
        <div>
          <h1 className="font-display" style={{ fontSize: 34, fontWeight: 400 }}>Posts</h1>
          <div style={{ fontSize: 13, color: "#9A9188", marginTop: 2 }}>{posts.length} total posts</div>
        </div>
        <button className="btn btn-primary" onClick={() => setModal({})}>
          <Plus size={14} /> New Post
        </button>
      </div>

      {/* Filters */}
      <div style={{ display: "flex", gap: 10, marginBottom: 20, flexWrap: "wrap" }}>
        <input className="input" style={{ width: 200 }} placeholder="Search posts..." value={search} onChange={e => setSearch(e.target.value)} />
        <select className="input" style={{ width: 160 }} value={filterBrand} onChange={e => setFilterBrand(e.target.value)}>
          <option value="">All Brands</option>
          {BRANDS.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
        </select>
        <select className="input" style={{ width: 140 }} value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
          <option value="">All Statuses</option>
          {STATUSES.map(s => <option key={s}>{s}</option>)}
        </select>
        <select className="input" style={{ width: 140 }} value={filterPlatform} onChange={e => setFilterPlatform(e.target.value)}>
          <option value="">All Platforms</option>
          {PLATFORMS.map(p => <option key={p}>{p}</option>)}
        </select>
        {(filterBrand || filterStatus || filterPlatform || search) && (
          <button className="btn btn-ghost" onClick={() => { setFilterBrand(""); setFilterStatus(""); setFilterPlatform(""); setSearch(""); }} style={{ fontSize: 12 }}>
            Clear filters
          </button>
        )}
      </div>

      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        {loading ? (
          <div style={{ padding: 32 }}>
            {[1,2,3,4,5].map(i => <div key={i} className="skeleton" style={{ height: 40, marginBottom: 8 }} />)}
          </div>
        ) : filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: "48px 24px" }}>
            <div style={{ fontSize: 13, color: "#9A9188", marginBottom: 12 }}>No posts found.</div>
            <button className="btn btn-primary" onClick={() => setModal({})}>Add Your First Post</button>
          </div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Title</th>
                <th>Brand</th>
                <th>Status</th>
                <th>Platform</th>
                <th>Type</th>
                <th>Date</th>
                <th>Views</th>
                <th style={{ textAlign: "right" }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(p => {
                const brand = BRANDS.find(b => b.id === p.brand_id);
                return (
                  <tr key={p.id}>
                    <td>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        {p.top_performer && <Star size={12} fill="#B89A5A" color="#B89A5A" />}
                        <span style={{ fontWeight: p.top_performer ? 500 : 300, maxWidth: 220, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", display: "block" }}>
                          {p.title}
                        </span>
                      </div>
                    </td>
                    <td>
                      {brand && (
                        <span className="brand-pill" style={{ background: brand.color + "20", color: brand.color }}>
                          <span style={{ width: 5, height: 5, borderRadius: "50%", background: brand.color, display: "inline-block" }} />
                          {brand.abbr}
                        </span>
                      )}
                    </td>
                    <td>
                      <span style={{ fontSize: 11, padding: "3px 8px", borderRadius: 100, background: STATUS_COLORS[p.status || "Idea"] || "#EDE8E1", color: STATUS_TEXT[p.status || "Idea"] || "#7D7470" }}>
                        {p.status}
                      </span>
                    </td>
                    <td style={{ fontSize: 12, color: "#7D7470" }}>{p.platform || "—"}</td>
                    <td style={{ fontSize: 12, color: "#7D7470" }}>{p.content_type || "—"}</td>
                    <td style={{ fontSize: 12, color: "#9A9188" }}>
                      {p.publish_date ? new Date(p.publish_date).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "—"}
                    </td>
                    <td style={{ fontSize: 12 }}>{p.views ? p.views.toLocaleString() : "—"}</td>
                    <td>
                      <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
                        {p.drive_link && (
                          <a href={p.drive_link} target="_blank" rel="noopener noreferrer" style={{ color: "#9A9188", display: "flex" }}>
                            <ExternalLink size={13} />
                          </a>
                        )}
                        <button onClick={() => setModal(p)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 12, color: "#B89A5A", fontFamily: "var(--font-jost)" }}>Edit</button>
                        <button onClick={() => deletePost(p.id)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 12, color: "#C8432A", fontFamily: "var(--font-jost)" }}>Del</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {modal !== false && <PostModal post={modal} onClose={() => setModal(false)} onSave={load} />}
    </div>
  );
}
