"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import type { Idea } from "@/types";
import { Plus, X, ArrowRight } from "lucide-react";

const BRANDS = [
  { id: "20e8bb0e-29fd-492e-ad91-2beb239e4b0f", name: "Ash Couture", abbr: "AC", color: "#2C2C2A" },
  { id: "caa9919a-5fe0-4e67-844a-fd75f3170516", name: "Digital Course Agency", abbr: "DCA", color: "#C8432A" },
  { id: "ba48df91-58dc-4471-93f4-1c2a9ba69d35", name: "Digital Expert School", abbr: "DES", color: "#185FA5" },
  { id: "a80ef03f-697b-47da-9c73-81b9b4d2717e", name: "Lux Leisure Lifestyle", abbr: "LLL", color: "#888480" },
  { id: "f4aec731-0842-493e-b17f-56e5265318ac", name: "Opulent Outreach Group", abbr: "OOG", color: "#B89A5A" },
  { id: "41d737ec-4a5a-425c-9f1e-ad509988c3d8", name: "TikTok Digital Income", abbr: "TDI", color: "#534AB7" },
];

const URGENCY_COLOR: Record<string, string> = { High: "#C8432A", Medium: "#B89A5A", Low: "#9A9188" };

function IdeaModal({ idea, onClose, onSave }: { idea: Partial<Idea> | null; onClose: () => void; onSave: () => void }) {
  const [form, setForm] = useState<Partial<Idea>>(idea || { type: "Content idea", urgency: "Medium", status: "Idea" });
  const [saving, setSaving] = useState(false);
  const set = (k: keyof Idea, v: unknown) => setForm(f => ({ ...f, [k]: v }));

  async function save() {
    setSaving(true);
    if (form.id) await supabase.from("ideas").update(form).eq("id", form.id);
    else await supabase.from("ideas").insert(form);
    setSaving(false);
    onSave(); onClose();
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div className="font-display" style={{ fontSize: 22 }}>{form.id ? "Edit Idea" : "Capture Idea"}</div>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "#9A9188" }}><X size={18} /></button>
        </div>
        <div style={{ display: "grid", gap: 12 }}>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Idea *</label>
            <input className="input" value={form.title || ""} onChange={e => set("title", e.target.value)} placeholder="What's the idea?" />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Brand</label>
              <select className="input" value={form.brand_id || ""} onChange={e => set("brand_id", e.target.value)}>
                <option value="">—</option>
                {BRANDS.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Type</label>
              <select className="input" value={form.type || "Content idea"} onChange={e => set("type", e.target.value)}>
                {["Content idea", "Business idea", "Offer idea", "Collab idea", "Campaign idea"].map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Urgency</label>
              <select className="input" value={form.urgency || "Medium"} onChange={e => set("urgency", e.target.value)}>
                {["High", "Medium", "Low"].map(u => <option key={u}>{u}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Content Type</label>
              <select className="input" value={form.content_type || ""} onChange={e => set("content_type", e.target.value)}>
                <option value="">—</option>
                {["Reel", "Carousel", "Static", "Story", "YouTube", "Blog"].map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Notes</label>
            <textarea className="input" rows={3} value={form.notes || ""} onChange={e => set("notes", e.target.value)} placeholder="Any context, inspiration, or details..." style={{ resize: "vertical" }} />
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 20, justifyContent: "flex-end" }}>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={saving || !form.title}>
            {saving ? "Saving..." : "Save Idea"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function IdeasPage() {
  const [ideas, setIdeas] = useState<Idea[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<Partial<Idea> | null | false>(false);
  const [filterBrand, setFilterBrand] = useState("");
  const [filterUrgency, setFilterUrgency] = useState("");
  const [search, setSearch] = useState("");

  async function load() {
    setLoading(true);
    const { data } = await supabase.from("ideas").select("*").order("created_at", { ascending: false });
    setIdeas(data || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function promoteToPost(idea: Idea) {
    await supabase.from("posts").insert({ title: idea.title, brand_id: idea.brand_id, content_type: idea.content_type, status: "Idea" });
    await supabase.from("ideas").update({ status: "Promoted to post" }).eq("id", idea.id);
    load();
  }

  async function deleteIdea(id: string) {
    if (!confirm("Delete this idea?")) return;
    await supabase.from("ideas").delete().eq("id", id);
    load();
  }

  const filtered = ideas.filter(i => {
    if (filterBrand && i.brand_id !== filterBrand) return false;
    if (filterUrgency && i.urgency !== filterUrgency) return false;
    if (search && !i.title.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const grouped: Record<string, Idea[]> = {};
  filtered.forEach(i => {
    const key = i.urgency || "Medium";
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push(i);
  });

  return (
    <div style={{ maxWidth: 1100, animation: "slideUp 0.4s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 28 }}>
        <div>
          <h1 className="font-display" style={{ fontSize: 34, fontWeight: 400 }}>Ideas Bank</h1>
          <div style={{ fontSize: 13, color: "#9A9188", marginTop: 2 }}>{ideas.length} ideas captured</div>
        </div>
        <button className="btn btn-primary" onClick={() => setModal({})}>
          <Plus size={14} /> Capture Idea
        </button>
      </div>

      <div style={{ display: "flex", gap: 10, marginBottom: 24 }}>
        <input className="input" style={{ width: 220 }} placeholder="Search ideas..." value={search} onChange={e => setSearch(e.target.value)} />
        <select className="input" style={{ width: 160 }} value={filterBrand} onChange={e => setFilterBrand(e.target.value)}>
          <option value="">All Brands</option>
          {BRANDS.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
        </select>
        <select className="input" style={{ width: 130 }} value={filterUrgency} onChange={e => setFilterUrgency(e.target.value)}>
          <option value="">All Urgency</option>
          <option>High</option><option>Medium</option><option>Low</option>
        </select>
      </div>

      {loading ? (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12 }}>
          {[1,2,3,4,5,6].map(i => <div key={i} className="skeleton" style={{ height: 100 }} />)}
        </div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: "center", padding: "64px 0" }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>💡</div>
          <div style={{ fontSize: 14, color: "#9A9188", marginBottom: 16 }}>No ideas yet. Start capturing.</div>
          <button className="btn btn-primary" onClick={() => setModal({})}>Capture First Idea</button>
        </div>
      ) : (
        <div>
          {["High", "Medium", "Low"].map(urgency => {
            const items = grouped[urgency];
            if (!items || items.length === 0) return null;
            return (
              <div key={urgency} style={{ marginBottom: 28 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
                  <span style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: URGENCY_COLOR[urgency], fontWeight: 500 }}>
                    {urgency} Urgency
                  </span>
                  <span style={{ fontSize: 11, color: "#B8B0A5" }}>({items.length})</span>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 12 }}>
                  {items.map(idea => {
                    const brand = BRANDS.find(b => b.id === idea.brand_id);
                    return (
                      <div key={idea.id} className="card" style={{ borderLeft: `3px solid ${URGENCY_COLOR[urgency]}` }}>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                          <span style={{ fontSize: 13, fontWeight: 400, flex: 1 }}>{idea.title}</span>
                          <div style={{ display: "flex", gap: 8, marginLeft: 12 }}>
                            <button onClick={() => setModal(idea)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 12, color: "#B89A5A", fontFamily: "var(--font-jost)" }}>Edit</button>
                            <button onClick={() => deleteIdea(idea.id)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 12, color: "#C8432A", fontFamily: "var(--font-jost)" }}>×</button>
                          </div>
                        </div>
                        <div style={{ display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
                          {brand && <span className="brand-pill" style={{ background: brand.color + "20", color: brand.color }}>{brand.abbr}</span>}
                          {idea.type && <span style={{ fontSize: 11, color: "#9A9188" }}>{idea.type}</span>}
                          {idea.content_type && <span style={{ fontSize: 11, color: "#9A9188" }}>· {idea.content_type}</span>}
                        </div>
                        {idea.notes && <div style={{ fontSize: 12, color: "#7D7470", marginTop: 8, lineHeight: 1.5 }}>{idea.notes}</div>}
                        <button
                          onClick={() => promoteToPost(idea)}
                          style={{ marginTop: 10, background: "none", border: "none", cursor: "pointer", fontSize: 11, color: "#B89A5A", display: "flex", alignItems: "center", gap: 4, fontFamily: "var(--font-jost)", padding: 0 }}
                        >
                          Promote to Post <ArrowRight size={10} />
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {modal !== false && <IdeaModal idea={modal} onClose={() => setModal(false)} onSave={load} />}
    </div>
  );
}
