"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { Plus, X, Users, TrendingUp, DollarSign } from "lucide-react";

interface Call {
  id: string;
  call_date: string | null;
  lead_name: string | null;
  offer: string | null;
  outcome: string | null;
  revenue: number | null;
  follow_up_date: string | null;
  notes: string | null;
  closer: string | null;
  created_at: string;
}

const OUTCOMES = ["Closed", "Follow up", "No show", "Not qualified", "Objection - price", "Objection - timing", "Lost"];
const OFFERS = [
  "Digital Empire $32,500", "Digital Launch $24,500", "Digital Build $12,500", "Digital Scale $15,000",
  "Digital CEO VIP Weekend $8,500", "6-Month Mentorship $6,000", "Teach & Be Rich $997",
  "Brand Launch + Content $4,997", "Ultimate Brand & Marketing Retainer $9,997/mo", "Other"
];

function CallModal({ call, onClose, onSave }: { call: Partial<Call> | null; onClose: () => void; onSave: () => void }) {
  const today = new Date().toISOString().split("T")[0];
  const [form, setForm] = useState<Partial<Call>>(call || { call_date: today, revenue: 0, closer: "Ash" });
  const [saving, setSaving] = useState(false);
  const set = (k: keyof Call, v: unknown) => setForm(f => ({ ...f, [k]: v }));

  async function save() {
    setSaving(true);
    if (form.id) await supabase.from("calls").update(form).eq("id", form.id);
    else await supabase.from("calls").insert(form);
    setSaving(false);
    onSave(); onClose();
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div className="font-display" style={{ fontSize: 22 }}>{form.id ? "Edit Call" : "Log Sales Call"}</div>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "#9A9188" }}><X size={18} /></button>
        </div>
        <div style={{ display: "grid", gap: 12 }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Lead Name</label>
              <input className="input" value={form.lead_name || ""} onChange={e => set("lead_name", e.target.value)} placeholder="First name or full name" />
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Call Date</label>
              <input className="input" type="date" value={form.call_date || today} onChange={e => set("call_date", e.target.value)} />
            </div>
          </div>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Offer Presented</label>
            <select className="input" value={form.offer || ""} onChange={e => set("offer", e.target.value)}>
              <option value="">—</option>
              {OFFERS.map(o => <option key={o}>{o}</option>)}
            </select>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Outcome</label>
              <select className="input" value={form.outcome || ""} onChange={e => set("outcome", e.target.value)}>
                <option value="">—</option>
                {OUTCOMES.map(o => <option key={o}>{o}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Revenue Closed $</label>
              <input className="input" type="number" value={form.revenue || ""} onChange={e => set("revenue", parseFloat(e.target.value))} />
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Closer</label>
              <select className="input" value={form.closer || "Ash"} onChange={e => set("closer", e.target.value)}>
                <option>Ash</option>
                <option>Saron</option>
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Follow Up Date</label>
              <input className="input" type="date" value={form.follow_up_date || ""} onChange={e => set("follow_up_date", e.target.value)} />
            </div>
          </div>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Notes</label>
            <textarea className="input" rows={3} value={form.notes || ""} onChange={e => set("notes", e.target.value)} placeholder="Objections, context, next steps..." style={{ resize: "vertical" }} />
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 20, justifyContent: "flex-end" }}>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={saving}>{saving ? "Saving..." : "Log Call"}</button>
        </div>
      </div>
    </div>
  );
}

export default function CallsPage() {
  const [calls, setCalls] = useState<Call[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<Partial<Call> | null | false>(false);
  const [filterOutcome, setFilterOutcome] = useState("");
  const [filterCloser, setFilterCloser] = useState("");

  async function load() {
    setLoading(true);
    const { data } = await supabase.from("calls").select("*").order("call_date", { ascending: false });
    setCalls(data || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  const filtered = calls.filter(c => {
    if (filterOutcome && c.outcome !== filterOutcome) return false;
    if (filterCloser && c.closer !== filterCloser) return false;
    return true;
  });

  const totalRevenue = calls.reduce((s, c) => s + (c.revenue || 0), 0);
  const closes = calls.filter(c => c.outcome === "Closed").length;
  const closeRate = calls.length > 0 ? Math.round((closes / calls.filter(c => c.outcome && c.outcome !== "No show").length) * 100) : 0;
  const followUps = calls.filter(c => c.follow_up_date && new Date(c.follow_up_date) >= new Date()).length;

  const OUTCOME_STYLE: Record<string, { bg: string; color: string }> = {
    Closed: { bg: "#D1FAE5", color: "#065F46" },
    "Follow up": { bg: "#DBEAFE", color: "#1E40AF" },
    "No show": { bg: "#EDE8E1", color: "#9A9188" },
    "Not qualified": { bg: "#EDE8E1", color: "#9A9188" },
    Lost: { bg: "#FEE2E2", color: "#991B1B" },
    "Objection - price": { bg: "#FEF3C7", color: "#92400E" },
    "Objection - timing": { bg: "#FEF3C7", color: "#92400E" },
  };

  return (
    <div style={{ maxWidth: 1100, animation: "slideUp 0.4s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
        <div>
          <h1 className="font-display" style={{ fontSize: 34, fontWeight: 400 }}>Sales Calls</h1>
          <div style={{ fontSize: 13, color: "#9A9188", marginTop: 2 }}>{calls.length} calls logged</div>
        </div>
        <button className="btn btn-primary" onClick={() => setModal({})}><Plus size={14} /> Log Call</button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 24 }}>
        <div className="card" style={{ borderTop: "3px solid #B89A5A" }}>
          <div style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "#9A9188", marginBottom: 6 }}>Revenue Closed</div>
          <div className="font-display" style={{ fontSize: 28 }}>${totalRevenue.toLocaleString()}</div>
        </div>
        <div className="card" style={{ borderTop: "3px solid #065F46" }}>
          <div style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "#9A9188", marginBottom: 6 }}>Close Rate</div>
          <div className="font-display" style={{ fontSize: 28 }}>{closeRate}%</div>
        </div>
        <div className="card" style={{ borderTop: "3px solid #2C2C2A" }}>
          <div style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "#9A9188", marginBottom: 6 }}>Total Closes</div>
          <div className="font-display" style={{ fontSize: 28 }}>{closes}</div>
        </div>
        <div className="card" style={{ borderTop: "3px solid #185FA5" }}>
          <div style={{ fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase", color: "#9A9188", marginBottom: 6 }}>Pending Follow Ups</div>
          <div className="font-display" style={{ fontSize: 28 }}>{followUps}</div>
        </div>
      </div>

      <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
        <select className="input" style={{ width: 180 }} value={filterOutcome} onChange={e => setFilterOutcome(e.target.value)}>
          <option value="">All Outcomes</option>
          {OUTCOMES.map(o => <option key={o}>{o}</option>)}
        </select>
        <select className="input" style={{ width: 140 }} value={filterCloser} onChange={e => setFilterCloser(e.target.value)}>
          <option value="">All Closers</option>
          <option>Ash</option>
          <option>Saron</option>
        </select>
      </div>

      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        {loading ? (
          <div style={{ padding: 24 }}>{[1,2,3,4].map(i => <div key={i} className="skeleton" style={{ height: 44, marginBottom: 8 }} />)}</div>
        ) : filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: "48px 0" }}>
            <Users size={32} color="#B8B0A5" style={{ margin: "0 auto 12px" }} />
            <div style={{ fontSize: 13, color: "#9A9188", marginBottom: 12 }}>No calls logged yet.</div>
            <button className="btn btn-primary" onClick={() => setModal({})}>Log First Call</button>
          </div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Lead</th>
                <th>Offer</th>
                <th>Outcome</th>
                <th>Revenue</th>
                <th>Closer</th>
                <th>Follow Up</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(c => {
                const style = OUTCOME_STYLE[c.outcome || ""] || { bg: "#EDE8E1", color: "#9A9188" };
                return (
                  <tr key={c.id}>
                    <td style={{ fontSize: 12, color: "#9A9188", whiteSpace: "nowrap" }}>
                      {c.call_date ? new Date(c.call_date).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "—"}
                    </td>
                    <td style={{ fontSize: 13, fontWeight: 400 }}>{c.lead_name || "Unknown"}</td>
                    <td style={{ fontSize: 12, color: "#7D7470", maxWidth: 160, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{c.offer || "—"}</td>
                    <td>
                      {c.outcome && (
                        <span style={{ fontSize: 11, padding: "3px 8px", borderRadius: 100, background: style.bg, color: style.color }}>
                          {c.outcome}
                        </span>
                      )}
                    </td>
                    <td style={{ fontSize: 13, fontWeight: c.revenue && c.revenue > 0 ? 500 : 300, color: c.revenue && c.revenue > 0 ? "#065F46" : "#9A9188" }}>
                      {c.revenue && c.revenue > 0 ? `$${c.revenue.toLocaleString()}` : "—"}
                    </td>
                    <td style={{ fontSize: 12, color: "#7D7470" }}>{c.closer || "—"}</td>
                    <td style={{ fontSize: 12, color: c.follow_up_date && new Date(c.follow_up_date) >= new Date() ? "#1E40AF" : "#9A9188" }}>
                      {c.follow_up_date ? new Date(c.follow_up_date).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "—"}
                    </td>
                    <td>
                      <button onClick={() => setModal(c)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 12, color: "#B89A5A", fontFamily: "var(--font-jost)" }}>Edit</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {modal !== false && <CallModal call={modal} onClose={() => setModal(false)} onSave={load} />}
    </div>
  );
}
