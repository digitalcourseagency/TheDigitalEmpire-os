"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { Plus, X, ChevronDown, ChevronRight } from "lucide-react";

interface Series {
  id: string;
  name: string;
  brand_id: string | null;
  platform: string | null;
  description: string | null;
  status: string | null;
  created_at: string;
}

interface Episode {
  id: string;
  series_id: string | null;
  episode_number: number | null;
  title: string | null;
  description: string | null;
  status: string | null;
  publish_date: string | null;
  drive_link: string | null;
  youtube_url: string | null;
  repurposed: boolean | null;
  created_at: string;
}

const BRANDS = [
  { id: "20e8bb0e-29fd-492e-ad91-2beb239e4b0f", name: "Ash Couture", abbr: "AC", color: "#2C2C2A" },
  { id: "caa9919a-5fe0-4e67-844a-fd75f3170516", name: "Digital Course Agency", abbr: "DCA", color: "#C8432A" },
  { id: "ba48df91-58dc-4471-93f4-1c2a9ba69d35", name: "Digital Expert School", abbr: "DES", color: "#185FA5" },
  { id: "a80ef03f-697b-47da-9c73-81b9b4d2717e", name: "Lux Leisure Lifestyle", abbr: "LLL", color: "#888480" },
  { id: "f4aec731-0842-493e-b17f-56e5265318ac", name: "Opulent Outreach Group", abbr: "OOG", color: "#B89A5A" },
  { id: "41d737ec-4a5a-425c-9f1e-ad509988c3d8", name: "TikTok Digital Income", abbr: "TDI", color: "#534AB7" },
];

const EP_STATUSES = ["Idea", "Scripted", "Filmed", "Edited", "Scheduled", "Live"];

function SeriesModal({ series, onClose, onSave }: { series: Partial<Series> | null; onClose: () => void; onSave: () => void }) {
  const [form, setForm] = useState<Partial<Series>>(series || { status: "Active" });
  const [saving, setSaving] = useState(false);
  const set = (k: keyof Series, v: unknown) => setForm(f => ({ ...f, [k]: v }));

  async function save() {
    setSaving(true);
    if (form.id) await supabase.from("series").update(form).eq("id", form.id);
    else await supabase.from("series").insert(form);
    setSaving(false);
    onSave(); onClose();
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div className="font-display" style={{ fontSize: 22 }}>{form.id ? "Edit Series" : "New Series"}</div>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "#9A9188" }}><X size={18} /></button>
        </div>
        <div style={{ display: "grid", gap: 12 }}>
          <input className="input" placeholder="Series name *" value={form.name || ""} onChange={e => set("name", e.target.value)} />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Brand</label>
              <select className="input" value={form.brand_id || ""} onChange={e => set("brand_id", e.target.value)}>
                <option value="">—</option>
                {BRANDS.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Platform</label>
              <select className="input" value={form.platform || ""} onChange={e => set("platform", e.target.value)}>
                <option value="">—</option>
                {["Instagram", "TikTok", "YouTube", "Substack", "All"].map(p => <option key={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Status</label>
              <select className="input" value={form.status || "Active"} onChange={e => set("status", e.target.value)}>
                {["Active", "Paused", "Complete", "Archived"].map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Description</label>
            <textarea className="input" rows={2} value={form.description || ""} onChange={e => set("description", e.target.value)} style={{ resize: "vertical" }} />
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 20, justifyContent: "flex-end" }}>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={saving || !form.name}>{saving ? "Saving..." : "Save"}</button>
        </div>
      </div>
    </div>
  );
}

function EpisodeModal({ episode, seriesId, onClose, onSave }: { episode: Partial<Episode> | null; seriesId: string; onClose: () => void; onSave: () => void }) {
  const [form, setForm] = useState<Partial<Episode>>(episode || { series_id: seriesId, status: "Idea", repurposed: false });
  const [saving, setSaving] = useState(false);
  const set = (k: keyof Episode, v: unknown) => setForm(f => ({ ...f, [k]: v }));

  async function save() {
    setSaving(true);
    if (form.id) await supabase.from("episodes").update(form).eq("id", form.id);
    else await supabase.from("episodes").insert({ ...form, series_id: seriesId });
    setSaving(false);
    onSave(); onClose();
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div className="font-display" style={{ fontSize: 22 }}>{form.id ? "Edit Episode" : "Add Episode"}</div>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "#9A9188" }}><X size={18} /></button>
        </div>
        <div style={{ display: "grid", gap: 12 }}>
          <div style={{ display: "grid", gridTemplateColumns: "80px 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Ep #</label>
              <input className="input" type="number" value={form.episode_number || ""} onChange={e => set("episode_number", parseInt(e.target.value))} />
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Title</label>
              <input className="input" value={form.title || ""} onChange={e => set("title", e.target.value)} placeholder="Episode title" />
            </div>
          </div>
          <div>
            <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Description</label>
            <textarea className="input" rows={2} value={form.description || ""} onChange={e => set("description", e.target.value)} style={{ resize: "vertical" }} />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Status</label>
              <select className="input" value={form.status || "Idea"} onChange={e => set("status", e.target.value)}>
                {EP_STATUSES.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, letterSpacing: "0.08em", textTransform: "uppercase", color: "#9A9188", display: "block", marginBottom: 4 }}>Publish Date</label>
              <input className="input" type="date" value={form.publish_date || ""} onChange={e => set("publish_date", e.target.value)} />
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <input className="input" placeholder="Drive link" value={form.drive_link || ""} onChange={e => set("drive_link", e.target.value)} />
            <input className="input" placeholder="YouTube URL" value={form.youtube_url || ""} onChange={e => set("youtube_url", e.target.value)} />
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <input type="checkbox" id="repurposed" checked={!!form.repurposed} onChange={e => set("repurposed", e.target.checked)} />
            <label htmlFor="repurposed" style={{ fontSize: 13, cursor: "pointer" }}>Repurposed to other platforms</label>
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, marginTop: 20, justifyContent: "flex-end" }}>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={saving}>{saving ? "Saving..." : "Save Episode"}</button>
        </div>
      </div>
    </div>
  );
}

function SeriesCard({ series, onEdit }: { series: Series; onEdit: () => void }) {
  const [expanded, setExpanded] = useState(false);
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [epModal, setEpModal] = useState<Partial<Episode> | null | false>(false);
  const brand = BRANDS.find(b => b.id === series.brand_id);

  async function loadEps() {
    const { data } = await supabase.from("episodes").select("*").eq("series_id", series.id).order("episode_number");
    setEpisodes(data || []);
  }

  function toggle() {
    if (!expanded) loadEps();
    setExpanded(e => !e);
  }

  const STATUS_COLOR: Record<string, string> = { Active: "#D1FAE5", Paused: "#FEF3C7", Complete: "#DBEAFE", Archived: "#EDE8E1" };
  const EP_STATUS_COLOR: Record<string, { bg: string; c: string }> = {
    Idea: { bg: "#EDE8E1", c: "#7D7470" }, Scripted: { bg: "#FEF3C7", c: "#92400E" },
    Filmed: { bg: "#DBEAFE", c: "#1E40AF" }, Edited: { bg: "#E0E7FF", c: "#3730A3" },
    Scheduled: { bg: "#D1FAE5", c: "#065F46" }, Live: { bg: "#B89A5A22", c: "#7A6535" },
  };

  return (
    <div className="card" style={{ padding: 0, overflow: "hidden" }}>
      <div style={{ padding: "16px 20px", display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer" }} onClick={toggle}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          {expanded ? <ChevronDown size={16} color="#9A9188" /> : <ChevronRight size={16} color="#9A9188" />}
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontSize: 15, fontWeight: 500 }}>{series.name}</span>
              {brand && <span className="brand-pill" style={{ background: brand.color + "20", color: brand.color }}>{brand.abbr}</span>}
              <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 100, background: STATUS_COLOR[series.status || "Active"] || "#EDE8E1", color: "#7D7470" }}>{series.status}</span>
            </div>
            {series.description && <div style={{ fontSize: 12, color: "#9A9188", marginTop: 2 }}>{series.description}</div>}
          </div>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          {series.platform && <span style={{ fontSize: 11, color: "#9A9188" }}>{series.platform}</span>}
          <button onClick={e => { e.stopPropagation(); onEdit(); }} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 12, color: "#B89A5A", fontFamily: "var(--font-jost)" }}>Edit</button>
        </div>
      </div>

      {expanded && (
        <div style={{ borderTop: "1px solid #F7F4F0" }}>
          <div style={{ padding: "12px 20px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ fontSize: 12, color: "#9A9188" }}>{episodes.length} episodes</span>
            <button className="btn btn-ghost" onClick={() => setEpModal({})} style={{ fontSize: 12, padding: "5px 12px" }}>
              <Plus size={12} /> Add Episode
            </button>
          </div>
          {episodes.length > 0 && (
            <table className="data-table">
              <thead>
                <tr>
                  <th style={{ width: 50 }}>#</th>
                  <th>Title</th>
                  <th>Status</th>
                  <th>Date</th>
                  <th>Repurposed</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {episodes.map(ep => {
                  const s = EP_STATUS_COLOR[ep.status || "Idea"] || { bg: "#EDE8E1", c: "#7D7470" };
                  return (
                    <tr key={ep.id}>
                      <td style={{ color: "#9A9188", fontSize: 12 }}>E{ep.episode_number || "?"}</td>
                      <td style={{ fontSize: 13 }}>{ep.title || "Untitled"}</td>
                      <td><span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 100, background: s.bg, color: s.c }}>{ep.status}</span></td>
                      <td style={{ fontSize: 12, color: "#9A9188" }}>{ep.publish_date ? new Date(ep.publish_date).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "—"}</td>
                      <td style={{ fontSize: 12, color: ep.repurposed ? "#065F46" : "#9A9188" }}>{ep.repurposed ? "✓" : "—"}</td>
                      <td><button onClick={() => setEpModal(ep)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 12, color: "#B89A5A", fontFamily: "var(--font-jost)" }}>Edit</button></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      )}

      {epModal !== false && <EpisodeModal episode={epModal} seriesId={series.id} onClose={() => setEpModal(false)} onSave={loadEps} />}
    </div>
  );
}

export default function SeriesPage() {
  const [series, setSeries] = useState<Series[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<Partial<Series> | null | false>(false);

  async function load() {
    setLoading(true);
    const { data } = await supabase.from("series").select("*").order("created_at", { ascending: false });
    setSeries(data || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  return (
    <div style={{ maxWidth: 900, animation: "slideUp 0.4s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 28 }}>
        <div>
          <h1 className="font-display" style={{ fontSize: 34, fontWeight: 400 }}>Series</h1>
          <div style={{ fontSize: 13, color: "#9A9188", marginTop: 2 }}>{series.length} series · {series.filter(s => s.status === "Active").length} active</div>
        </div>
        <button className="btn btn-primary" onClick={() => setModal({})}><Plus size={14} /> New Series</button>
      </div>

      {loading ? (
        <div style={{ display: "grid", gap: 12 }}>{[1,2,3].map(i => <div key={i} className="skeleton" style={{ height: 64 }} />)}</div>
      ) : series.length === 0 ? (
        <div style={{ textAlign: "center", padding: "64px 0" }}>
          <div style={{ fontSize: 13, color: "#9A9188", marginBottom: 12 }}>No series yet.</div>
          <button className="btn btn-primary" onClick={() => setModal({})}>Create First Series</button>
        </div>
      ) : (
        <div style={{ display: "grid", gap: 12 }}>
          {series.map(s => <SeriesCard key={s.id} series={s} onEdit={() => setModal(s)} />)}
        </div>
      )}

      {modal !== false && <SeriesModal series={modal} onClose={() => setModal(false)} onSave={load} />}
    </div>
  );
}
