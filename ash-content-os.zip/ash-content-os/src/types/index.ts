export interface Brand {
  id: string;
  name: string;
  handle: string | null;
  color: string | null;
  platform_focus: string | null;
  primary_cta: string | null;
  created_at: string;
}

export interface Post {
  id: string;
  brand_id: string | null;
  title: string;
  hook: string | null;
  caption: string | null;
  platform: string | null;
  content_type: string | null;
  video_format: string | null;
  topic: string | null;
  theme: string | null;
  purpose: string | null;
  cta_keyword: string | null;
  manychat_keyword: string | null;
  status: string | null;
  publish_date: string | null;
  views: number | null;
  reach: number | null;
  saves: number | null;
  revenue_attributed: number | null;
  top_performer: boolean | null;
  drive_link: string | null;
  created_at: string;
  brand?: Brand;
}

export interface Idea {
  id: string;
  title: string;
  type: string | null;
  brand_id: string | null;
  content_type: string | null;
  video_format: string | null;
  urgency: string | null;
  notes: string | null;
  status: string | null;
  created_at: string;
  brand?: Brand;
}

export interface Analytics {
  id: string;
  week_of: string;
  brand_id: string | null;
  ig_followers: number | null;
  ig_follower_growth: number | null;
  best_reel_views: number | null;
  profile_visits: number | null;
  link_bio_clicks: number | null;
  manychat_dms: number | null;
  strategy_calls_booked: number | null;
  stan_store_revenue: number | null;
  new_des_members: number | null;
  des_elite_signups: number | null;
  tiktok_views: number | null;
  youtube_views: number | null;
  posts_published: number | null;
  best_post: string | null;
  revenue_total: number | null;
  created_at: string;
  brand?: Brand;
}

export interface WeeklyGoal {
  id: string;
  week_of: string;
  ac_posts_target: number;
  ac_posts_actual: number;
  dca_posts_target: number;
  dca_posts_actual: number;
  lll_posts_target: number;
  lll_posts_actual: number;
  oog_posts_target: number;
  oog_posts_actual: number;
  tiktok_posts_target: number;
  tiktok_posts_actual: number;
  webinars_target: number;
  webinars_actual: number;
  strategy_calls_target: number;
  strategy_calls_actual: number;
  revenue_target: number;
  revenue_actual: number;
  posting_streak: number;
  top_3_priorities: string | null;
  week_score: number | null;
  created_at: string;
}

export interface Launch {
  id: string;
  name: string;
  brand_id: string | null;
  offer: string | null;
  price: number | null;
  revenue_goal: number | null;
  revenue_closed: number | null;
  launch_date: string | null;
  status: string | null;
  target_audience: string | null;
  manychat_keyword: string | null;
  landing_page_url: string | null;
  phase1_complete: boolean | null;
  phase2_complete: boolean | null;
  phase3_complete: boolean | null;
  phase4_complete: boolean | null;
  created_at: string;
  brand?: Brand;
}

export interface Inspo {
  id: string;
  title: string;
  source_account: string | null;
  source_url: string | null;
  platform: string | null;
  category: string | null;
  video_format: string | null;
  topic: string | null;
  theme: string | null;
  brand_id: string | null;
  status: string | null;
  priority: string | null;
  notes: string | null;
  is_trending: boolean | null;
  created_at: string;
  brand?: Brand;
}

export interface Keyword {
  id: string;
  keyword: string;
  brand_id: string | null;
  destination: string | null;
  destination_url: string | null;
  purpose: string | null;
  active: boolean | null;
  triggers_this_week: number | null;
  triggers_total: number | null;
  created_at: string;
  brand?: Brand;
}

export interface QuarterlyGoal {
  id: string;
  quarter: string;
  year: number;
  revenue_target: number;
  revenue_actual: number;
  ig_followers_target: number;
  ig_followers_actual: number;
  dca_clients_target: number;
  dca_clients_actual: number;
  tiktok_followers_target: number;
  tiktok_followers_actual: number;
  created_at: string;
}
